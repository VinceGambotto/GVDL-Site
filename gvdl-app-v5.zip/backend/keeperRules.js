// The league's actual keeper cost table, keyed by original draft round.
// Round 8 and any undrafted/waiver player both cost 1 point.
const ROUND_COST = { 1: 8, 2: 7, 3: 6, 4: 5, 5: 4, 6: 3, 7: 2 };
const UNDRAFTED_OR_LATE_COST = 1;
const MAX_CONSECUTIVE_KEEPER_SEASONS = 3;
const BASE_POINTS_PER_SEASON = 20;

function costForRound(round) {
  if (!round || round >= 8) return UNDRAFTED_OR_LATE_COST;
  return ROUND_COST[round] ?? UNDRAFTED_OR_LATE_COST;
}

// "Half of unused points roll over, rounding up" + a fresh 20-point
// allotment each season. This matches the numbers in the original 2025
// spreadsheet (e.g. an owner who finished with points left over started
// the next season above the 20-point baseline).
function computeNextSeasonStartingPoints(pointsRemainingThisSeason) {
  const clamped = Math.max(0, pointsRemainingThisSeason);
  return BASE_POINTS_PER_SEASON + Math.ceil(clamped / 2);
}

// Given a player's keeper_seasons history (rows ordered most-recent-season
// first) and the season currently being decided, returns how many
// consecutive prior seasons they were kept by THIS team, and whether
// keeping them again this season would be allowed.
function evaluateKeeperEligibility(priorSeasonsKeptDescending) {
  let streak = 0;
  for (const wasKept of priorSeasonsKeptDescending) {
    if (wasKept) streak++;
    else break; // streak only counts consecutive seasons ending right before this one
  }
  return {
    consecutivePriorSeasons: streak,
    eligibleToKeep: streak < MAX_CONSECUTIVE_KEEPER_SEASONS,
  };
}

module.exports = {
  ROUND_COST,
  UNDRAFTED_OR_LATE_COST,
  MAX_CONSECUTIVE_KEEPER_SEASONS,
  BASE_POINTS_PER_SEASON,
  costForRound,
  computeNextSeasonStartingPoints,
  evaluateKeeperEligibility,
};
