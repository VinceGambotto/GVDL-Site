const { pool } = require("./db");
const sleeper = require("./sleeper");
const { syncWeeklyScores } = require("./weeklyScores");
const { generateNewsletter } = require("./gemini");

function fmt(n) {
  return (Math.round(Number(n) * 10) / 10).toFixed(1);
}

// Gathers the real numbers for one week: team scores, top individual
// performances, trades, and waiver/free-agent moves.
async function buildNewsletterContext({ week, season }) {
  const allPlayers = await sleeper.getAllPlayers();
  const nameOf = (id) => {
    const p = allPlayers[id];
    return p ? `${p.first_name || ""} ${p.last_name || ""}`.trim() : `Player ${id}`;
  };

  const teamsRes = await pool.query("SELECT id, owner_name FROM teams");
  const ownerById = Object.fromEntries(teamsRes.rows.map((t) => [t.id, t.owner_name]));

  const sections = [];

  // Team scores
  const scoresRes = await pool.query(
    `SELECT team_id, actual_points, optimal_points FROM weekly_scores
     WHERE season = $1 AND week = $2 ORDER BY actual_points DESC`,
    [String(season), week]
  );
  if (scoresRes.rows.length) {
    sections.push(
      "TEAM SCORES (highest to lowest; 'best possible' = points if they had started their optimal lineup):\n" +
        scoresRes.rows
          .map(
            (r) =>
              `- ${ownerById[r.team_id]}: ${fmt(r.actual_points)} pts (best possible ${fmt(r.optimal_points)}, left ${fmt(
                r.optimal_points - r.actual_points
              )} on the bench)`
          )
          .join("\n")
    );
  } else {
    sections.push("TEAM SCORES: none recorded for this week yet.");
  }

  // Top individual performances
  const topRes = await pool.query(
    `SELECT sleeper_player_id, points FROM player_weekly_points
     WHERE season = $1 AND week = $2 ORDER BY points DESC LIMIT 5`,
    [String(season), week]
  );
  sections.push(
    "TOP INDIVIDUAL PERFORMANCES (first one is the Week MVP):\n" +
      (topRes.rows.length
        ? topRes.rows.map((r) => `- ${nameOf(r.sleeper_player_id)}: ${fmt(r.points)} pts`).join("\n")
        : "none recorded")
  );

  // Transactions for the week
  const txRes = await pool.query(
    `SELECT type, team_id, details FROM transactions_log WHERE week = $1 ORDER BY occurred_at ASC`,
    [week]
  );

  const describeSide = (details, rosterId) => {
    const got = Object.entries(details.adds || {})
      .filter(([, r]) => String(r) === String(rosterId))
      .map(([pid]) => nameOf(pid));
    const gave = Object.entries(details.drops || {})
      .filter(([, r]) => String(r) === String(rosterId))
      .map(([pid]) => nameOf(pid));
    return { got, gave };
  };

  const rosterToOwner = {};
  const rosterRes = await pool.query("SELECT id, sleeper_roster_id, owner_name FROM teams");
  rosterRes.rows.forEach((t) => (rosterToOwner[t.sleeper_roster_id] = t.owner_name));

  const seenTrades = new Set();
  const tradeLines = [];
  const movesByOwner = {};
  for (const tx of txRes.rows) {
    const d = tx.details;
    if (tx.type === "trade") {
      if (seenTrades.has(d.transaction_id)) continue;
      seenTrades.add(d.transaction_id);
      const sides = (d.roster_ids || []).map((rid) => {
        const s = describeSide(d, rid);
        return `${rosterToOwner[String(rid)] || `Roster ${rid}`} receives ${s.got.join(", ") || "nothing (picks only)"}`;
      });
      const picks = (d.draft_picks || []).length ? ` (also ${(d.draft_picks || []).length} draft pick(s) moved)` : "";
      tradeLines.push(`- ${sides.join(" | ")}${picks}`);
    } else {
      const rid = (d.roster_ids || [])[0];
      const s = describeSide(d, rid);
      const owner = rosterToOwner[String(rid)] || ownerById[tx.team_id] || `Roster ${rid}`;
      if (s.got.length || s.gave.length) {
        movesByOwner[owner] = movesByOwner[owner] || [];
        movesByOwner[owner].push(`added ${s.got.join(", ") || "none"}, dropped ${s.gave.join(", ") || "none"}`);
      }
    }
  }

  sections.push("TRADES THIS WEEK:\n" + (tradeLines.length ? tradeLines.join("\n") : "none"));
  const moveLines = Object.entries(movesByOwner).map(([owner, moves]) => `- ${owner}: ${moves.join("; ")}`);
  sections.push("ROSTER MOVES BY TEAM (waiver/free agent):\n" + (moveLines.length ? moveLines.slice(0, 25).join("\n") : "none"));

  return sections.join("\n\n");
}

// Runs on the weekly schedule: refresh scores, then write and store the
// newsletter for the most recently completed week.
// Checks whether the most recently completed week already has a storyline,
// and writes one if not. Safe to call often — it's a no-op once that week's
// storyline exists. This is what makes the storyline fully automatic: no
// button to click, it just appears once there's a finished week to write about.
async function ensureLatestStorylineGenerated({ refreshScores = false } = {}) {
  if (!process.env.GEMINI_API_KEY) return { skipped: "GEMINI_API_KEY not set" };
  const leagueId = process.env.SLEEPER_LEAGUE_ID;
  if (!leagueId) return { skipped: "SLEEPER_LEAGUE_ID not set" };

  try {
    const state = await sleeper.getState();
    const week = Number(state.week) - 1;
    const season = state.season;
    if (!(week >= 1)) return { skipped: "no completed week yet" };

    const existing = await pool.query(
      "SELECT 1 FROM storylines WHERE kind = 'newsletter' AND season = $1 AND week = $2",
      [Number(season), week]
    );
    if (existing.rows.length) return { skipped: `week ${week} already generated` };

    if (refreshScores) await syncWeeklyScores(leagueId, { seasonsBack: 1 });
    const context = await buildNewsletterContext({ week, season });
    const content = await generateNewsletter({ context, week, season });
    await pool.query(
      `INSERT INTO storylines (season, week, kind, title, content) VALUES ($1,$2,'newsletter',$3,$4)`,
      [Number(season), week, `GVDL Storyline — Week ${week}`, content]
    );
    console.log(`[storyline] auto-generated week ${week}`);
    return { generated: true, week, season };
  } catch (err) {
    console.error("[storyline] auto-generation failed:", err.message);
    return { error: err.message };
  }
}

// Kept as an explicit name for the Tuesday cron job, which always refreshes
// scores first since it's the "official" weekly run.
async function generateAndStoreWeeklyNewsletter() {
  return ensureLatestStorylineGenerated({ refreshScores: true });
}

module.exports = { buildNewsletterContext, generateAndStoreWeeklyNewsletter, ensureLatestStorylineGenerated };
