const { simulatePlayoffs } = require("./playoffPredictor");

// Your league's actual odds table for the 6 non-playoff teams, keyed by
// standings rank (7th = best of the non-playoff group, 12th = worst). The
// worst-record team (12th) gets the best shot at pick 1; the best-of-the-six
// team (7th, the one that just missed the playoffs) gets the longest odds.
const LOTTERY_ODDS = { 7: 5, 8: 10, 9: 15, 10: 20, 11: 30, 12: 40 };
const LOTTERY_ITERATIONS = 5000;

// Simulates the lottery. "Highest odds" has to mean "best chance at the BEST
// pick (1)" — so the actual draw math picks pick-1's winner first (weighted
// by the full odds table), then re-normalizes the remaining teams' odds and
// draws pick 2, and so on down to pick 6 (standard weighted-lottery-without-
// replacement, the same style as the NBA draft lottery). The league's
// "drawn backward from 6 to 1" describes the live reveal order for suspense
// — announcing the pick-6 team first, saving the pick-1 reveal for last —
// not the math; doing the actual random draw in that literal order would
// invert the odds and give the WORST-odds team the best chance at pick 1.
function drawLotteryOnce(pool) {
  const remaining = pool.map((t) => ({ ...t }));
  const result = {}; // pick number -> team
  for (let pick = 1; pick <= 6; pick++) {
    const total = remaining.reduce((s, t) => s + t.odds, 0);
    let r = Math.random() * total;
    let chosenIdx = remaining.length - 1;
    for (let i = 0; i < remaining.length; i++) {
      if (r < remaining[i].odds) { chosenIdx = i; break; }
      r -= remaining[i].odds;
    }
    const [chosen] = remaining.splice(chosenIdx, 1);
    result[pick] = chosen;
  }
  return result;
}

async function predictDraftOrder(leagueId) {
  const playoffSim = await simulatePlayoffs(leagueId);
  const ranked = playoffSim.teams; // already sorted by avgFinishRank ascending

  const playoffTeams = ranked.slice(0, 6);
  const lotteryTeams = ranked.slice(6, 12);

  // Picks 7-12: playoff teams, by estimated finish. We do NOT simulate the
  // actual playoff bracket (that's a separate, much noisier single-elimination
  // problem) — this uses each team's regular-season-simulated finish as a
  // stand-in for playoff result, worst-of-the-six picking 7th, best picking 12th.
  const playoffPickOrder = [...playoffTeams].reverse().map((t, idx) => ({
    pick: 7 + idx,
    teamId: t.teamId,
    ownerName: t.ownerName,
    basis: "estimated from simulated regular-season finish, not an actual playoff bracket result",
  }));

  // Picks 1-6: the lottery, run many times for a probability table, plus one
  // sample draw to show a concrete possible outcome.
  const lotteryPool = lotteryTeams.map((t, idx) => ({
    teamId: t.teamId,
    ownerName: t.ownerName,
    standingsRank: 7 + idx,
    odds: LOTTERY_ODDS[7 + idx] || 1,
  }));

  const pickCounts = {}; // teamId -> { [pickNo]: count }
  lotteryPool.forEach((t) => (pickCounts[t.teamId] = {}));

  for (let i = 0; i < LOTTERY_ITERATIONS; i++) {
    const drawn = drawLotteryOnce(lotteryPool);
    for (const [pick, team] of Object.entries(drawn)) {
      pickCounts[team.teamId][pick] = (pickCounts[team.teamId][pick] || 0) + 1;
    }
  }

  const lotteryProbabilities = lotteryPool.map((t) => ({
    teamId: t.teamId,
    ownerName: t.ownerName,
    standingsRank: t.standingsRank,
    baseOdds: `${t.odds}/120`,
    pickProbabilities: [1, 2, 3, 4, 5, 6].map((pick) => ({
      pick,
      probability: Math.round(((pickCounts[t.teamId][pick] || 0) / LOTTERY_ITERATIONS) * 1000) / 10,
    })),
  }));

  const sampleDraw = drawLotteryOnce(lotteryPool);
  const sampleLotteryResult = Object.entries(sampleDraw)
    .map(([pick, team]) => ({ pick: Number(pick), teamId: team.teamId, ownerName: team.ownerName }))
    .sort((a, b) => a.pick - b.pick);

  return {
    season: playoffSim.season,
    playoffPickOrder,
    lotteryProbabilities,
    sampleLotteryResult,
    fullPickOrder: [...sampleLotteryResult, ...playoffPickOrder].sort((a, b) => a.pick - b.pick),
  };
}

module.exports = { predictDraftOrder, LOTTERY_ODDS, drawLotteryOnce };
