// Google Gemini client — free tier, no billing required for normal use.
// Get a key at https://aistudio.google.com/app/apikey (not console.anthropic.com).
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const BASE = "https://generativelanguage.googleapis.com/v1beta/models";

async function callGemini(prompt, maxOutputTokens) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY is not set on this server. Get a free key at https://aistudio.google.com/app/apikey and add it to your .env file."
    );
  }

  const res = await fetch(`${BASE}/${MODEL}:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { maxOutputTokens: maxOutputTokens || 1200 },
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    const msg = data?.error?.message || `Gemini request failed (${res.status})`;
    throw new Error(msg);
  }
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
  if (!text) {
    const reason = data.candidates?.[0]?.finishReason;
    throw new Error(`Gemini returned no text${reason ? ` (finishReason: ${reason})` : ""}.`);
  }
  return text.trim();
}

/**
 * Short recap/storyline for a team or the league, from real data you assemble.
 */
async function generateStoryline({ context, tone = "playful beat-writer" }) {
  const prompt = `You are the in-house storyline writer for a 12-team keeper fantasy football league called the GVDL (the GV Dynasty League).
Write in a ${tone} tone: punchy, a little dramatic, genuinely funny, never mean-spirited.
Keep it to 2-4 short paragraphs. Use real names and numbers from the context below — don't invent stats.

LEAGUE CONTEXT:
${context}

Write the storyline now.`;
  return callGemini(prompt, 1000);
}

/**
 * Weekly report: headlines, roster moves by team, and breaking news (trades).
 */
async function generateNewsletter({ context, week, season }) {
  const prompt = `You are the editor of the weekly report for a 12-team keeper fantasy football league called the GVDL (the GV Dynasty League).
Write the Week ${week}, ${season} report using ONLY the real data given below — never invent a stat, score, or name.

Structure it with these sections, each with a short bold heading:
1. **Headlines** — the top 2-3 storylines from this week's scores and biggest individual performances.
2. **Breaking News** — any trades this week: what each side gave up and got, and what it signals.
3. **Roster Moves, By Team** — for each team that made a waiver or free-agent move this week, one line on what they added/dropped. Skip teams with no moves; don't list them as "no moves."

Keep it lively and a little irreverent, like a real fantasy football newsletter — but never mean-spirited about any specific owner. If a whole section has nothing to report, say so briefly rather than padding it out. Keep the whole thing under 500 words.

WEEK DATA:
${context}

Write the report now.`;
  return callGemini(prompt, 1800);
}

module.exports = { generateStoryline, generateNewsletter };
