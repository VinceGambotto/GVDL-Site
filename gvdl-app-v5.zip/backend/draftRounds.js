const { pool } = require("./db");
const sleeper = require("./sleeper");

// Walks the league's season chain (current + past, via previous_league_id),
// pulls every draft's picks, and records:
//  1. player_draft_rounds: the MOST RECENT round each player was drafted in
//     (drives keeper cost — a player re-drafted later gets a fresh round).
//  2. draft_picks: every pick each team made (drives draft analysis).
async function syncDraftRounds(leagueId, { maxSeasons = 6 } = {}) {
  const chain = await sleeper.getLeagueSeasonChain(leagueId, maxSeasons);
  const seasonsOldestFirst = [...chain].reverse();
  const allPlayers = await sleeper.getAllPlayers();

  const teamsRes = await pool.query("SELECT id, sleeper_owner_id FROM teams WHERE sleeper_owner_id IS NOT NULL");
  const teamIdByOwner = Object.fromEntries(teamsRes.rows.map((t) => [t.sleeper_owner_id, t.id]));

  const latestRoundByPlayer = new Map();
  const pickRows = [];
  const slotMapRows = [];

  for (const league of seasonsOldestFirst) {
    let drafts;
    try {
      drafts = await sleeper.getLeagueDrafts(league.league_id);
    } catch (err) {
      console.warn(`[draftRounds] couldn't load drafts for league ${league.league_id}: ${err.message}`);
      continue;
    }

    // roster_id -> owner, as a fallback when a pick has no picked_by.
    const ownerByRoster = {};
    try {
      const rosters = await sleeper.getRosters(league.league_id);
      rosters.forEach((r) => (ownerByRoster[String(r.roster_id)] = r.owner_id));
    } catch (err) {
      /* fallback only; fine to skip */
    }

    for (const draft of drafts) {
      let picks;
      try {
        picks = await sleeper.getDraftPicks(draft.draft_id);
      } catch (err) {
        console.warn(`[draftRounds] couldn't load picks for draft ${draft.draft_id}: ${err.message}`);
        continue;
      }

      // Slot map: which original roster sits in each draft slot, so a traded
      // FUTURE pick ("2027 Round 1, originally Ben's") can be translated into
      // an actual overall pick number once that draft's order is set.
      try {
        const full = await sleeper.getDraft(draft.draft_id);
        const slotToRoster = full.slot_to_roster_id || {};
        const numSlots = Object.keys(slotToRoster).length;
        const rounds = full.settings?.rounds || 0;
        const isSnake = (full.type || "snake") === "snake";
        if (numSlots && rounds && full.type !== "auction") {
          for (let round = 1; round <= rounds; round++) {
            for (let slot = 1; slot <= numSlots; slot++) {
              const effectiveSlot = isSnake && round % 2 === 0 ? numSlots - slot + 1 : slot;
              const pickNo = (round - 1) * numSlots + effectiveSlot;
              const originalRosterId = slotToRoster[String(slot)];
              if (originalRosterId == null) continue;
              slotMapRows.push({
                draftId: String(draft.draft_id),
                season: String(league.season),
                round,
                originalRosterId: String(originalRosterId),
                pickNo,
              });
            }
          }
        }
      } catch (err) {
        console.warn(`[draftRounds] couldn't load slot order for draft ${draft.draft_id}: ${err.message}`);
      }
      for (const pick of picks) {
        if (!pick.player_id || !pick.round) continue;
        latestRoundByPlayer.set(pick.player_id, { round: pick.round, season: league.season });

        const ownerId = pick.picked_by || ownerByRoster[String(pick.roster_id)];
        const p = allPlayers[pick.player_id];
        const name =
          pick.metadata?.first_name || pick.metadata?.last_name
            ? `${pick.metadata.first_name || ""} ${pick.metadata.last_name || ""}`.trim()
            : p
            ? `${p.first_name || ""} ${p.last_name || ""}`.trim()
            : `Player ${pick.player_id}`;
        pickRows.push({
          draftId: String(draft.draft_id),
          pickNo: pick.pick_no,
          season: String(league.season),
          round: pick.round,
          teamId: teamIdByOwner[ownerId] || null,
          playerId: pick.player_id,
          name,
          position: pick.metadata?.position || p?.position || null,
        });
      }
    }
  }

  for (const [playerId, { round, season }] of latestRoundByPlayer.entries()) {
    await pool.query(
      `INSERT INTO player_draft_rounds (sleeper_player_id, round, season, updated_at)
       VALUES ($1,$2,$3, now())
       ON CONFLICT (sleeper_player_id) DO UPDATE
         SET round = EXCLUDED.round, season = EXCLUDED.season, updated_at = now()`,
      [playerId, round, season]
    );
  }

  if (slotMapRows.length) {
    await pool.query(
      `INSERT INTO draft_slot_map (draft_id, season, round, original_roster_id, pick_no)
       SELECT * FROM unnest($1::text[], $2::text[], $3::int[], $4::text[], $5::int[])
       ON CONFLICT (draft_id, round, original_roster_id) DO UPDATE SET pick_no = EXCLUDED.pick_no`,
      [
        slotMapRows.map((r) => r.draftId),
        slotMapRows.map((r) => r.season),
        slotMapRows.map((r) => r.round),
        slotMapRows.map((r) => r.originalRosterId),
        slotMapRows.map((r) => r.pickNo),
      ]
    );
  }

  if (pickRows.length) {
    await pool.query(
      `INSERT INTO draft_picks (draft_id, pick_no, season, round, team_id, sleeper_player_id, player_name, position)
       SELECT * FROM unnest($1::text[], $2::int[], $3::text[], $4::int[], $5::int[], $6::text[], $7::text[], $8::text[])
       ON CONFLICT (draft_id, pick_no) DO UPDATE
         SET season = EXCLUDED.season, round = EXCLUDED.round, team_id = EXCLUDED.team_id,
             sleeper_player_id = EXCLUDED.sleeper_player_id, player_name = EXCLUDED.player_name, position = EXCLUDED.position`,
      [
        pickRows.map((r) => r.draftId),
        pickRows.map((r) => r.pickNo),
        pickRows.map((r) => r.season),
        pickRows.map((r) => r.round),
        pickRows.map((r) => r.teamId),
        pickRows.map((r) => r.playerId),
        pickRows.map((r) => r.name),
        pickRows.map((r) => r.position),
      ]
    );
  }

  return {
    playersRecorded: latestRoundByPlayer.size,
    picksRecorded: pickRows.length,
    slotMapRecorded: slotMapRows.length,
    seasonsWalked: seasonsOldestFirst.length,
  };
}

module.exports = { syncDraftRounds };
