// Matches free-text player names (e.g. from the old 2025 spreadsheet) to
// Sleeper player IDs. Punctuation, hyphens, and Jr/Sr/II/III suffixes are
// ignored so "Amon-Ra St. Brown" and "Marvin Harrison Jr." still match.
const FANTASY_POSITIONS = new Set(["QB", "RB", "WR", "TE", "K", "DEF"]);
const indexCache = new WeakMap();

function normalizeName(name) {
  return String(name || "")
    .toLowerCase()
    .replace(/[.'’]/g, "")
    .replace(/-/g, " ")
    .replace(/\b(jr|sr|ii|iii|iv)\b/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function getIndex(allPlayers) {
  if (indexCache.has(allPlayers)) return indexCache.get(allPlayers);
  const idx = new Map();
  for (const [id, p] of Object.entries(allPlayers)) {
    if (!p.first_name && !p.last_name) continue;
    const key = normalizeName(`${p.first_name || ""} ${p.last_name || ""}`);
    // If two players share a name, prefer the active fantasy-relevant one.
    const score = (FANTASY_POSITIONS.has(p.position) ? 4 : 0) + (p.active ? 2 : 0) + (p.team ? 1 : 0);
    const cur = idx.get(key);
    if (!cur || score > cur.score) idx.set(key, { id, score });
  }
  indexCache.set(allPlayers, idx);
  return idx;
}

function resolvePlayerId(name, allPlayers) {
  return getIndex(allPlayers).get(normalizeName(name))?.id || null;
}

module.exports = { normalizeName, resolvePlayerId };
