const { pool } = require("./db");
const sleeper = require("./sleeper");

// "FLEX" accepts RB/WR/TE, "SUPER_FLEX" additionally accepts QB. Anything
// else in roster_positions (BN, IR, TAXI) is a non-starting slot.
const FLEX_ELIGIBLE = ["RB", "WR", "TE"];
const SUPERFLEX_ELIGIBLE = ["QB", "RB", "WR", "TE"];

function computeOptimalLineup(startingSlots, playersOnRoster) {
  const pool_ = [...playersOnRoster];
  let total = 0;

  const exactSlots = startingSlots.filter((s) => !["FLEX", "SUPER_FLEX", "BN", "IR", "TAXI"].includes(s));
  const flexSlots = startingSlots.filter((s) => s === "FLEX");
  const superFlexSlots = startingSlots.filter((s) => s === "SUPER_FLEX");

  function takeBest(eligiblePositions) {
    let bestIdx = -1;
    let bestPoints = -Infinity;
    pool_.forEach((p, i) => {
      if (eligiblePositions.includes(p.position) && p.points > bestPoints) {
        bestPoints = p.points;
        bestIdx = i;
      }
    });
    if (bestIdx === -1) return;
    total += pool_[bestIdx].points;
    pool_.splice(bestIdx, 1);
  }

  for (const slot of exactSlots) takeBest([slot]);
  for (const _ of flexSlots) takeBest(FLEX_ELIGIBLE);
  for (const _ of superFlexSlots) takeBest(SUPERFLEX_ELIGIBLE);

  return total;
}

// Walks the current season AND past seasons (via previous_league_id) so
// players drafted/kept in earlier years have real points instead of zeros.
// Past seasons only sync once (they never change) unless refreshPast is set;
// the current season always refreshes.
async function syncWeeklyScores(leagueId, { seasonsBack = 3, refreshPast = false } = {}) {
  const chain = await sleeper.getLeagueSeasonChain(leagueId, seasonsBack);
  const state = await sleeper.getState();
  const currentSeason = String(state.season);
  const allPlayers = await sleeper.getAllPlayers();

  const teamsRes = await pool.query("SELECT id, sleeper_owner_id FROM teams WHERE sleeper_owner_id IS NOT NULL");
  const teamIdByOwner = Object.fromEntries(teamsRes.rows.map((t) => [t.sleeper_owner_id, t.id]));

  const seasonResults = [];

  for (const league of chain) {
    const season = String(league.season);
    const isCurrent = season === currentSeason;

    if (!isCurrent && !refreshPast) {
      const existing = await pool.query("SELECT 1 FROM weekly_scores WHERE season = $1 LIMIT 1", [season]);
      if (existing.rows.length) {
        seasonResults.push({ season, weeks: 0, skipped: true });
        continue;
      }
    }

    // Roster IDs can differ between seasons, so map through the owner.
    let rosters = [];
    try {
      rosters = await sleeper.getRosters(league.league_id);
    } catch (err) {
      console.warn(`[weeklyScores] rosters for ${season} unavailable: ${err.message}`);
      continue;
    }
    const teamIdByRoster = {};
    for (const r of rosters) {
      const tid = teamIdByOwner[r.owner_id];
      if (tid) teamIdByRoster[String(r.roster_id)] = tid;
    }

    const startingSlots = league.roster_positions || [];
    const lastWeek = isCurrent ? Math.min(18, Math.max(1, Number(state.week) || 1)) : 18;
    let weeksSynced = 0;

    for (let week = 1; week <= lastWeek; week++) {
      let matchups;
      try {
        matchups = await sleeper.getMatchups(league.league_id, week);
      } catch (err) {
        continue;
      }
      // A week nobody has scored in yet (future week, or preseason) isn't real data.
      if (!matchups || !matchups.some((m) => Number(m.points) > 0)) continue;

      const ppw = new Map(); // dedupe: one row per player per week

      for (const m of matchups) {
        const teamId = teamIdByRoster[String(m.roster_id)];
        if (!teamId) continue;

        const starters = new Set((m.starters || []).filter((id) => id && id !== "0"));
        const actualPoints = m.starters_points
          ? m.starters_points.reduce((s, p) => s + (Number(p) || 0), 0)
          : Number(m.points) || 0;

        const rosterPlayers = (m.players || []).map((playerId) => ({
          playerId,
          position: allPlayers[playerId]?.position || "UNKNOWN",
          points: Number(m.players_points?.[playerId] || 0),
        }));
        const optimalPoints = computeOptimalLineup(startingSlots, rosterPlayers);

        await pool.query(
          `INSERT INTO weekly_scores (team_id, season, week, actual_points, optimal_points)
           VALUES ($1,$2,$3,$4,$5)
           ON CONFLICT (team_id, season, week) DO UPDATE
             SET actual_points = EXCLUDED.actual_points, optimal_points = EXCLUDED.optimal_points`,
          [teamId, season, week, actualPoints, optimalPoints]
        );

        for (const rp of rosterPlayers) {
          ppw.set(rp.playerId, {
            id: rp.playerId,
            points: rp.points,
            teamId,
            started: starters.has(rp.playerId),
            position: rp.position,
          });
        }
      }

      if (ppw.size) {
        const rows = [...ppw.values()];
        await pool.query(
          `INSERT INTO player_weekly_points (sleeper_player_id, season, week, points, team_id, started, position)
           SELECT * FROM unnest($1::text[], $2::text[], $3::int[], $4::numeric[], $5::int[], $6::boolean[], $7::text[])
           ON CONFLICT (sleeper_player_id, season, week) DO UPDATE
             SET points = EXCLUDED.points, team_id = EXCLUDED.team_id,
                 started = EXCLUDED.started, position = EXCLUDED.position`,
          [
            rows.map((r) => r.id),
            rows.map(() => season),
            rows.map(() => week),
            rows.map((r) => r.points),
            rows.map((r) => r.teamId),
            rows.map((r) => r.started),
            rows.map((r) => r.position),
          ]
        );
      }
      weeksSynced++;
    }
    seasonResults.push({ season, weeks: weeksSynced });
  }

  const summary = seasonResults
    .map((s) => (s.skipped ? `${s.season} (already synced)` : `${s.season} (${s.weeks} wk)`))
    .join(", ");
  return { seasons: seasonResults, summary };
}

module.exports = { syncWeeklyScores, computeOptimalLineup };
