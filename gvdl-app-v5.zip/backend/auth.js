const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const SECRET = process.env.JWT_SECRET || "change_this_secret";
const TOKEN_TTL = "12h";

// The commissioner's override code. Never used as a regular team PIN — it
// only clears a lost PIN so the real owner can set a fresh one (see the
// /recover route). Override via MASTER_PIN in .env if you want a different code.
const MASTER_PIN = process.env.MASTER_PIN || "4677";

function isValidPinFormat(pin) {
  return /^\d{4}$/.test(String(pin || ""));
}

function hashPin(pin) {
  return bcrypt.hashSync(String(pin), 10);
}

function verifyPin(pin, hash) {
  return bcrypt.compareSync(String(pin), hash);
}

function issueTeamToken(teamId) {
  return jwt.sign({ teamId }, SECRET, { expiresIn: TOKEN_TTL });
}

// Express middleware: requires a valid token for the :id in the route.
function requireTeamAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing auth token. Unlock this team with its PIN first." });

  try {
    const payload = jwt.verify(token, SECRET);
    if (String(payload.teamId) !== String(req.params.id)) {
      return res.status(403).json({ error: "This token doesn't unlock this team." });
    }
    next();
  } catch (err) {
    return res.status(401).json({ error: "Session expired or invalid. Enter the PIN again." });
  }
}

module.exports = { hashPin, verifyPin, issueTeamToken, requireTeamAuth, isValidPinFormat, MASTER_PIN };
