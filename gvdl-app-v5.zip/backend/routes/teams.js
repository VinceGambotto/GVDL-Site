const express = require("express");
const { pool } = require("../db");
const { hashPin, verifyPin, issueTeamToken, requireTeamAuth, isValidPinFormat, MASTER_PIN } = require("../auth");
const { notifyRecovery } = require("../notify");
const { costForRound, computeNextSeasonStartingPoints, evaluateKeeperEligibility } = require("../keeperRules");

const router = express.Router();

// GET /api/teams — league overview
router.get("/", async (req, res) => {
  const teamsRes = await pool.query("SELECT * FROM teams ORDER BY owner_name ASC");
  const teams = teamsRes.rows;

  const out = [];
  for (const team of teams) {
    const rosterRes = await pool.query(
      "SELECT * FROM roster_entries WHERE team_id = $1 AND is_active_on_sleeper = true ORDER BY is_keeper DESC, keeper_cost DESC NULLS LAST",
      [team.id]
    );
    const tradesRes = await pool.query("SELECT COUNT(*)::int AS n FROM trades_log WHERE team_id = $1", [team.id]);

    const pointsUsed = rosterRes.rows
      .filter((p) => p.is_keeper)
      .reduce((s, p) => s + Number(p.keeper_cost || 0), 0);

    out.push({
      id: team.id,
      ownerName: team.owner_name,
      hasPin: !!team.pin_hash,
      startingPoints: Number(team.starting_points),
      pointsUsed,
      pointsRemaining: Number(team.starting_points) - pointsUsed,
      tradeAllowance: team.trade_allowance,
      tradesUsed: tradesRes.rows[0].n,
      tradesRemaining: team.trade_allowance != null ? team.trade_allowance - tradesRes.rows[0].n : null,
      players: rosterRes.rows,
    });
  }

  res.json(out);
});

// GET /api/teams/recovery-log — recent PIN recoveries, for the home page panel
// (must be registered before the "/:id" route below, or Express will treat
// "recovery-log" as an :id value and this route will never be reached)
router.get("/recovery-log", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM recovery_log ORDER BY created_at DESC LIMIT 15");
  res.json(rows);
});

// GET /api/teams/:id — team detail + 2025 reference
router.get("/:id", async (req, res) => {
  const teamRes = await pool.query("SELECT * FROM teams WHERE id = $1", [req.params.id]);
  if (!teamRes.rows.length) return res.status(404).json({ error: "Team not found" });
  const team = teamRes.rows[0];

  const rosterRes = await pool.query(
    "SELECT * FROM roster_entries WHERE team_id = $1 AND is_active_on_sleeper = true ORDER BY is_keeper DESC, keeper_cost DESC NULLS LAST",
    [team.id]
  );
  const historyRes = await pool.query(
    "SELECT * FROM keeper_history_2025 WHERE owner_name = $1 ORDER BY kept DESC, cost DESC NULLS LAST",
    [team.owner_name]
  );
  const tradesRes = await pool.query(
    "SELECT * FROM trades_log WHERE team_id = $1 ORDER BY occurred_at DESC",
    [team.id]
  );

  res.json({
    id: team.id,
    ownerName: team.owner_name,
    hasPin: !!team.pin_hash,
    startingPoints: Number(team.starting_points),
    tradeAllowance: team.trade_allowance,
    players: rosterRes.rows,
    history2025: historyRes.rows,
    trades: tradesRes.rows,
  });
});

// POST /api/teams/:id/pin — claim (set) a PIN. Only works if none is set yet.
router.post("/:id/pin", async (req, res) => {
  const { pin } = req.body;
  if (!isValidPinFormat(pin)) {
    return res.status(400).json({ error: "PIN must be exactly 4 digits (e.g. 8214)." });
  }
  if (String(pin) === MASTER_PIN) {
    return res.status(400).json({ error: "That code is reserved for commissioner recovery — pick a different 4-digit PIN." });
  }

  const teamRes = await pool.query("SELECT * FROM teams WHERE id = $1", [req.params.id]);
  if (!teamRes.rows.length) return res.status(404).json({ error: "Team not found" });
  if (teamRes.rows[0].pin_hash) {
    return res.status(409).json({ error: "This team already has a PIN set." });
  }

  // Every team's PIN must be unique, so no owner can guess another team's
  // PIN just by trying their own. Hashes can't be compared directly, so this
  // checks the candidate against every other team's stored hash.
  const others = await pool.query("SELECT pin_hash FROM teams WHERE id <> $1 AND pin_hash IS NOT NULL", [req.params.id]);
  if (others.rows.some((r) => verifyPin(pin, r.pin_hash))) {
    return res.status(409).json({ error: "That PIN is already in use by another team. Each team's PIN must be unique — pick a different one." });
  }

  const hash = hashPin(pin);
  await pool.query("UPDATE teams SET pin_hash = $1, updated_at = now() WHERE id = $2", [hash, req.params.id]);
  const token = issueTeamToken(req.params.id);
  res.json({ token });
});

// POST /api/teams/:id/recover — commissioner-only. Clears a lost PIN using
// the master code so the real owner can set a brand new one. Never grants
// edit access by itself — it only unlocks the "set a PIN" step again.
router.post("/:id/recover", async (req, res) => {
  const { masterPin } = req.body;
  if (String(masterPin) !== MASTER_PIN) {
    return res.status(401).json({ error: "That's not the master code." });
  }
  const teamRes = await pool.query("SELECT * FROM teams WHERE id = $1", [req.params.id]);
  if (!teamRes.rows.length) return res.status(404).json({ error: "Team not found" });
  if (!teamRes.rows[0].pin_hash) {
    return res.status(400).json({ error: "This team doesn't have a PIN set — nothing to recover." });
  }

  await pool.query("UPDATE teams SET pin_hash = NULL, updated_at = now() WHERE id = $1", [req.params.id]);
  await notifyRecovery({ teamId: teamRes.rows[0].id, ownerName: teamRes.rows[0].owner_name });
  res.json({ ok: true, message: "PIN cleared. Set a new one now." });
});

// POST /api/teams/:id/unlock — verify PIN, get a session token
router.post("/:id/unlock", async (req, res) => {
  const { pin } = req.body;
  const teamRes = await pool.query("SELECT * FROM teams WHERE id = $1", [req.params.id]);
  if (!teamRes.rows.length) return res.status(404).json({ error: "Team not found" });
  const team = teamRes.rows[0];
  if (!team.pin_hash) return res.status(400).json({ error: "No PIN set for this team yet." });

  if (!verifyPin(pin, team.pin_hash)) {
    return res.status(401).json({ error: "Wrong PIN." });
  }
  const token = issueTeamToken(req.params.id);
  res.json({ token });
});

// PUT /api/teams/:id/keepers — set keeper flag/cost on roster entries (requires unlock)
router.put("/:id/keepers", requireTeamAuth, async (req, res) => {
  const { entries } = req.body; // [{ id, isKeeper, keeperCost }]
  if (!Array.isArray(entries)) return res.status(400).json({ error: "Body must include an entries array." });

  for (const e of entries) {
    await pool.query(
      `UPDATE roster_entries SET is_keeper = $1, keeper_cost = $2, updated_at = now()
       WHERE id = $3 AND team_id = $4`,
      [!!e.isKeeper, e.keeperCost ?? null, e.id, req.params.id]
    );
  }
  res.json({ ok: true });
});

// PUT /api/teams/:id/trade-allowance — commissioner/owner sets the season trade cap
router.put("/:id/trade-allowance", requireTeamAuth, async (req, res) => {
  const { allowance } = req.body;
  await pool.query("UPDATE teams SET trade_allowance = $1, updated_at = now() WHERE id = $2", [allowance, req.params.id]);
  res.json({ ok: true });
});

// PUT /api/teams/:id/name — rename a team from the Sleeper-default display name
// to your house nickname. If that nickname matches a 2025 keeper history owner,
// this also pulls in that owner's rolled-over starting points — this is the one
// step that ties a Sleeper roster to your league's past history as a single team.
router.put("/:id/name", requireTeamAuth, async (req, res) => {
  const { ownerName } = req.body;
  if (!ownerName) return res.status(400).json({ error: "ownerName is required" });

  const historyRes = await pool.query(
    "SELECT * FROM keeper_history_2025 WHERE owner_name = $1",
    [ownerName]
  );

  if (historyRes.rows.length) {
    const pointsForNextYear = historyRes.rows[0].points_for_next_year;
    await pool.query(
      "UPDATE teams SET owner_name = $1, starting_points = $2, updated_at = now() WHERE id = $3",
      [ownerName, pointsForNextYear, req.params.id]
    );

    // Best-effort: seed a 2025 keeper_seasons row per history player, matched
    // by name. This is what lets the 3-consecutive-season streak check see
    // one prior year. It's name-matching against free text from the old
    // spreadsheet, not a Sleeper ID, so an unusual name spelling could miss —
    // worth spot-checking the streak numbers the first season.
    for (const h of historyRes.rows) {
      await pool.query(
        `INSERT INTO keeper_seasons (team_id, sleeper_player_id, player_name, season, kept, cost)
         VALUES ($1, NULL, $2, '2025', $3, $4)
         ON CONFLICT (team_id, player_name, season) DO UPDATE SET kept = EXCLUDED.kept, cost = EXCLUDED.cost`,
        [req.params.id, h.player_name, h.kept, h.cost]
      );
    }

    return res.json({ ok: true, matchedHistory: true, startingPoints: pointsForNextYear });
  }

  await pool.query("UPDATE teams SET owner_name = $1, updated_at = now() WHERE id = $2", [ownerName, req.params.id]);
  res.json({ ok: true, matchedHistory: false });
});

// POST /api/teams/:id/autofill-costs — set keeper_cost on every active roster
// entry based on the player's most recent Sleeper draft round. Doesn't touch
// is_keeper — the owner still decides who to actually keep. Safe to re-run;
// it always recomputes from the latest draft-round data.
router.post("/:id/autofill-costs", requireTeamAuth, async (req, res) => {
  const rosterRes = await pool.query(
    "SELECT * FROM roster_entries WHERE team_id = $1 AND is_active_on_sleeper = true",
    [req.params.id]
  );

  let updated = 0;
  let noDraftData = 0;
  for (const p of rosterRes.rows) {
    let round = null;
    if (p.sleeper_player_id) {
      const r = await pool.query(
        "SELECT round FROM player_draft_rounds WHERE sleeper_player_id = $1",
        [p.sleeper_player_id]
      );
      if (r.rows.length) round = r.rows[0].round;
      else noDraftData++;
    }
    const cost = costForRound(round);
    await pool.query("UPDATE roster_entries SET keeper_cost = $1, updated_at = now() WHERE id = $2", [cost, p.id]);
    updated++;
  }

  res.json({
    ok: true,
    updated,
    noDraftDataCount: noDraftData,
    note: noDraftData
      ? `${noDraftData} player(s) had no draft history on file (treated as 1-point/undrafted) — run "Sync Draft History" if that looks wrong.`
      : undefined,
  });
});

// GET /api/teams/:id/keeper-eligibility — for each active roster entry,
// how many consecutive prior seasons this team has kept them, and whether
// keeping them again this season is still allowed under the 3-season cap.
router.get("/:id/keeper-eligibility", async (req, res) => {
  const rosterRes = await pool.query(
    "SELECT * FROM roster_entries WHERE team_id = $1 AND is_active_on_sleeper = true",
    [req.params.id]
  );

  const results = [];
  for (const p of rosterRes.rows) {
    const seasonsRes = await pool.query(
      `SELECT season, kept FROM keeper_seasons
       WHERE team_id = $1 AND player_name = $2
       ORDER BY season DESC`,
      [req.params.id, p.player_name]
    );
    const keptDescending = seasonsRes.rows.map((r) => r.kept);
    const evalResult = evaluateKeeperEligibility(keptDescending);
    results.push({
      rosterEntryId: p.id,
      playerName: p.player_name,
      ...evalResult,
    });
  }
  res.json(results);
});

// POST /api/teams/:id/close-season — locks in this season's keeper choices
// (writes keeper_seasons rows for the streak tracker), records the points
// math, and sets next season's starting_points using the league's rollover
// rule (20 base + half of unused, rounded up).
router.post("/:id/close-season", requireTeamAuth, async (req, res) => {
  const { season } = req.body;
  if (!season) return res.status(400).json({ error: "season is required, e.g. \"2026\"" });

  const teamRes = await pool.query("SELECT * FROM teams WHERE id = $1", [req.params.id]);
  if (!teamRes.rows.length) return res.status(404).json({ error: "Team not found" });
  const team = teamRes.rows[0];

  const rosterRes = await pool.query(
    "SELECT * FROM roster_entries WHERE team_id = $1 AND is_active_on_sleeper = true",
    [req.params.id]
  );

  const pointsUsed = rosterRes.rows
    .filter((p) => p.is_keeper)
    .reduce((s, p) => s + Number(p.keeper_cost || 0), 0);
  const pointsRemaining = Number(team.starting_points) - pointsUsed;
  const rollover = computeNextSeasonStartingPoints(pointsRemaining);

  for (const p of rosterRes.rows) {
    await pool.query(
      `INSERT INTO keeper_seasons (team_id, sleeper_player_id, player_name, season, kept, cost)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (team_id, player_name, season) DO UPDATE
         SET kept = EXCLUDED.kept, sleeper_player_id = EXCLUDED.sleeper_player_id, cost = EXCLUDED.cost`,
      [team.id, p.sleeper_player_id, p.player_name, season, p.is_keeper, p.is_keeper ? p.keeper_cost : null]
    );
  }

  await pool.query(
    `INSERT INTO season_history (team_id, season, starting_points, points_used, points_remaining, rollover_to_next_season)
     VALUES ($1,$2,$3,$4,$5,$6)
     ON CONFLICT (team_id, season) DO UPDATE
       SET starting_points = EXCLUDED.starting_points,
           points_used = EXCLUDED.points_used,
           points_remaining = EXCLUDED.points_remaining,
           rollover_to_next_season = EXCLUDED.rollover_to_next_season`,
    [team.id, season, team.starting_points, pointsUsed, pointsRemaining, rollover]
  );

  await pool.query("UPDATE teams SET starting_points = $1, updated_at = now() WHERE id = $2", [rollover, team.id]);

  res.json({ ok: true, season, pointsUsed, pointsRemaining, nextSeasonStartingPoints: rollover });
});

module.exports = router;
