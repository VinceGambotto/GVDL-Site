const express = require("express");
const { runSync } = require("../sync");
const { syncDraftRounds } = require("../draftRounds");
const { syncWeeklyScores } = require("../weeklyScores");
const { ensureLatestStorylineGenerated } = require("../newsletter");
const { pool } = require("../db");

const router = express.Router();

// POST /api/sync — manually trigger a Sleeper sync (also runs on a schedule)
router.post("/", async (req, res) => {
  const result = await runSync();
  res.json(result);
});

// POST /api/sync/drafts — walk past + current league drafts to record each
// player's most recent draft round. This is slower and draft history barely
// changes mid-season, so it's manual/on-demand rather than on the 30-min
// schedule. Run it once after setup, and again each year after your draft.
router.post("/drafts", async (req, res) => {
  const leagueId = process.env.SLEEPER_LEAGUE_ID;
  if (!leagueId) return res.status(400).json({ error: "SLEEPER_LEAGUE_ID is not set." });
  try {
    const result = await syncDraftRounds(leagueId);
    await pool.query("INSERT INTO sync_log (status, detail) VALUES ($1,$2)", [
      "ok",
      `Draft sync: ${result.picksRecorded} picks / ${result.playersRecorded} players / ${result.slotMapRecorded} slot mappings across ${result.seasonsWalked} season(s).`,
    ]);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/sync/log — recent sync history, so you can see it's actually running
router.get("/log", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM sync_log ORDER BY synced_at DESC LIMIT 20");
  res.json(rows);
});

// POST /api/sync/weekly-scores — pulls matchup data for every week played so
// far this season, computing each team's actual points and near-optimal
// lineup points, and caching per-player weekly points for the analytics page.
// Also manual/on-demand — run it after each week's games finish.
router.post("/weekly-scores", async (req, res) => {
  const leagueId = process.env.SLEEPER_LEAGUE_ID;
  if (!leagueId) return res.status(400).json({ error: "SLEEPER_LEAGUE_ID is not set." });
  try {
    const result = await syncWeeklyScores(leagueId, { refreshPast: !!req.body?.refreshPast });
    await pool.query("INSERT INTO sync_log (status, detail) VALUES ($1,$2)", [
      "ok",
      `Weekly scores synced: ${result.summary}.`,
    ]);
    ensureLatestStorylineGenerated().catch(() => {}); // fire-and-forget; don't block the sync response on AI generation
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
