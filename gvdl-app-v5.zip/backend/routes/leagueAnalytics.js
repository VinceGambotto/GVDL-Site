const express = require("express");
const { pool } = require("../db");

const router = express.Router();
const r1 = (n) => Math.round(Number(n) * 10) / 10;

// GET /api/analytics/league?season=2026 — every team's points vs. best possible
router.get("/league", async (req, res) => {
  try {
    const seasons = (await pool.query("SELECT DISTINCT season FROM weekly_scores ORDER BY season DESC")).rows.map((r) => r.season);
    const season = seasons.includes(req.query.season) ? req.query.season : seasons[0] || null;
    if (!season) return res.json({ seasons, season: null, teams: [], weekly: [] });

    const teams = (
      await pool.query(
        `SELECT t.id, t.owner_name, SUM(w.actual_points) AS actual, SUM(w.optimal_points) AS optimal, COUNT(*) AS weeks
         FROM weekly_scores w JOIN teams t ON t.id = w.team_id
         WHERE w.season = $1 GROUP BY t.id, t.owner_name ORDER BY actual DESC`,
        [season]
      )
    ).rows.map((t) => ({
      id: t.id,
      ownerName: t.owner_name,
      actual: r1(t.actual),
      optimal: r1(t.optimal),
      efficiency: Number(t.optimal) ? r1((Number(t.actual) / Number(t.optimal)) * 100) : null,
      leftOnBench: r1(t.optimal - t.actual),
      weeks: Number(t.weeks),
    }));

    const weekly = (
      await pool.query(
        `SELECT week, AVG(actual_points) AS a, AVG(optimal_points) AS o FROM weekly_scores
         WHERE season = $1 GROUP BY week ORDER BY week`,
        [season]
      )
    ).rows.map((w) => ({ week: w.week, avgActual: r1(w.a), avgOptimal: r1(w.o) }));

    res.json({ seasons, season, teams, weekly });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
