const express = require("express");
const { pool } = require("../db");
const { generateStoryline, generateNewsletter } = require("../gemini");
const { buildNewsletterContext } = require("../newsletter");

const router = express.Router();

// POST /api/copilot/storyline  { teamId?, tone? }
// With teamId: writes about that team specifically.
// Without: writes a league-wide storyline using every team's current state.
router.post("/storyline", async (req, res) => {
  const { teamId, tone } = req.body;

  try {
    let context;
    let scopeTeamId = null;

    if (teamId) {
      const teamRes = await pool.query("SELECT * FROM teams WHERE id = $1", [teamId]);
      if (!teamRes.rows.length) return res.status(404).json({ error: "Team not found" });
      const team = teamRes.rows[0];
      scopeTeamId = team.id;

      const rosterRes = await pool.query(
        "SELECT * FROM roster_entries WHERE team_id = $1 AND is_active_on_sleeper = true",
        [team.id]
      );
      const tradesRes = await pool.query("SELECT COUNT(*)::int AS n FROM trades_log WHERE team_id = $1", [team.id]);
      const keepers = rosterRes.rows.filter((p) => p.is_keeper);
      const pointsUsed = keepers.reduce((s, p) => s + Number(p.keeper_cost || 0), 0);

      context = `Team: ${team.owner_name}
Starting points: ${team.starting_points}
Points used on keepers: ${pointsUsed} (${team.starting_points - pointsUsed} remaining)
Keepers: ${keepers.map((p) => `${p.player_name} (${p.position}, ${p.keeper_cost} pts)`).join(", ") || "none set yet"}
Full roster: ${rosterRes.rows.map((p) => `${p.player_name} (${p.position})`).join(", ")}
Trades made this season: ${tradesRes.rows[0].n}${team.trade_allowance != null ? ` of ${team.trade_allowance} allowed` : ""}`;
    } else {
      const teamsRes = await pool.query("SELECT * FROM teams ORDER BY owner_name ASC");
      const lines = [];
      for (const team of teamsRes.rows) {
        const rosterRes = await pool.query(
          "SELECT * FROM roster_entries WHERE team_id = $1 AND is_active_on_sleeper = true AND is_keeper = true",
          [team.id]
        );
        const tradesRes = await pool.query("SELECT COUNT(*)::int AS n FROM trades_log WHERE team_id = $1", [team.id]);
        lines.push(
          `${team.owner_name}: ${rosterRes.rows.length} keepers (${rosterRes.rows.map((p) => p.player_name).join(", ") || "none yet"}), ${tradesRes.rows[0].n} trades made`
        );
      }
      context = lines.join("\n");
    }

    const content = await generateStoryline({ context, tone: tone || "playful beat-writer" });

    await pool.query(
      `INSERT INTO storylines (team_id, season, title, content) VALUES ($1, $2, $3, $4)`,
      [scopeTeamId, new Date().getFullYear(), teamId ? "Team Storyline" : "League Storyline", content]
    );

    res.json({ content });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/copilot/storylines — recent generated storylines
router.get("/storylines", async (req, res) => {
  const { rows } = await pool.query(
    `SELECT s.*, t.owner_name FROM storylines s LEFT JOIN teams t ON t.id = s.team_id WHERE s.kind = 'storyline' ORDER BY s.created_at DESC LIMIT 25`
  );
  res.json(rows);
});

// POST /api/copilot/newsletter { week, season }
// Builds real context from weekly scores, trades, and roster moves, then
// asks Claude to write it up. Also runs automatically on a schedule (see
// server.js) — this endpoint is what both the cron job and a manual
// "Generate Newsletter Now" button call.
router.post("/newsletter", async (req, res) => {
  try {
    const { week, season } = req.body;
    if (!week || !season) return res.status(400).json({ error: "week and season are required" });

    const context = await buildNewsletterContext({ week, season });
    const content = await generateNewsletter({ context, week, season });

    await pool.query(
      `INSERT INTO storylines (season, week, kind, title, content) VALUES ($1,$2,'newsletter',$3,$4)`,
      [season, week, `GVDL Weekly — Week ${week}`, content]
    );

    res.json({ content });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/copilot/newsletters — recent newsletters
router.get("/newsletters", async (req, res) => {
  const { rows } = await pool.query(
    `SELECT * FROM storylines WHERE kind = 'newsletter' ORDER BY created_at DESC LIMIT 10`
  );
  res.json(rows);
});

module.exports = router;
