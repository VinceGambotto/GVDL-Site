const express = require("express");
const { pool } = require("../db");
const sleeper = require("../sleeper");
const { resolvePlayerId } = require("../playerNames");

const router = express.Router();
const r1 = (n) => Math.round(Number(n) * 10) / 10;

let seasonCache = { value: null, at: 0 };
async function getCurrentSeason(fallback) {
  if (seasonCache.value && Date.now() - seasonCache.at < 10 * 60 * 1000) return seasonCache.value;
  try {
    const state = await sleeper.getState();
    seasonCache = { value: String(state.season), at: Date.now() };
    return seasonCache.value;
  } catch (err) {
    return fallback || String(new Date().getFullYear());
  }
}

// GET /api/teams/:id/analytics?season=2026
router.get("/:id/analytics", async (req, res) => {
  try {
    const teamRes = await pool.query("SELECT * FROM teams WHERE id = $1", [req.params.id]);
    if (!teamRes.rows.length) return res.status(404).json({ error: "Team not found" });
    const team = teamRes.rows[0];
    const notes = {};

    const allPlayers = await sleeper.getAllPlayers();
    const nameOf = (id) => {
      const p = allPlayers[id];
      return p ? `${p.first_name || ""} ${p.last_name || ""}`.trim() : `Player ${id}`;
    };
    const ownerByRoster = {};
    (await pool.query("SELECT sleeper_roster_id, owner_name FROM teams")).rows.forEach(
      (t) => (ownerByRoster[t.sleeper_roster_id] = t.owner_name)
    );

    // ---------- Seasons + weekly ----------
    // Union across every source of season data for this team, so the year
    // filter works even if, say, draft history has synced but weekly scores
    // haven't yet (or vice versa).
    const seasonsRes = await pool.query(
      `SELECT season FROM weekly_scores WHERE team_id = $1
       UNION SELECT season FROM draft_picks WHERE team_id = $1
       UNION SELECT season FROM keeper_seasons WHERE team_id = $1
       UNION SELECT '2025' WHERE EXISTS (SELECT 1 FROM keeper_history_2025 WHERE owner_name = $2)
       ORDER BY season DESC`,
      [team.id, team.owner_name]
    );
    const seasons = seasonsRes.rows.map((r) => r.season);
    const season = seasons.includes(req.query.season) ? req.query.season : seasons[0] || null;
    const currentSeason = await getCurrentSeason(seasons[0]);
    const posFilter = ["QB", "RB", "WR", "TE", "K", "DEF"].includes(req.query.position) ? req.query.position : null;
    const availablePositions = ["QB", "RB", "WR", "TE", "K", "DEF"];

    let weekly = [];
    let kpis = null;
    let positionBreakdown = [];
    let topScorers = [];
    if (season) {
      weekly = (
        await pool.query(
          `SELECT week, actual_points, optimal_points FROM weekly_scores
           WHERE team_id = $1 AND season = $2 ORDER BY week ASC`,
          [team.id, season]
        )
      ).rows.map((w) => ({
        week: w.week,
        actual: r1(w.actual_points),
        optimal: r1(w.optimal_points),
        leftOnBench: r1(w.optimal_points - w.actual_points),
      }));

      const totalActual = weekly.reduce((s, w) => s + w.actual, 0);
      const totalOptimal = weekly.reduce((s, w) => s + w.optimal, 0);
      const best = [...weekly].sort((a, b) => b.actual - a.actual)[0];
      const worst = [...weekly].sort((a, b) => a.actual - b.actual)[0];
      kpis = {
        season,
        weeks: weekly.length,
        totalActual: r1(totalActual),
        totalOptimal: r1(totalOptimal),
        efficiency: totalOptimal ? r1((totalActual / totalOptimal) * 100) : null,
        leftOnBench: r1(totalOptimal - totalActual),
        avgPerWeek: weekly.length ? r1(totalActual / weekly.length) : null,
        bestWeek: best ? { week: best.week, points: best.actual } : null,
        worstWeek: worst ? { week: worst.week, points: worst.actual } : null,
      };

      positionBreakdown = (
        await pool.query(
          `SELECT position, SUM(points) AS pts FROM player_weekly_points
           WHERE team_id = $1 AND season = $2 AND started = true AND position IS NOT NULL
           GROUP BY position ORDER BY pts DESC`,
          [team.id, season]
        )
      ).rows.map((r) => ({ position: r.position, points: r1(r.pts) }));

      topScorers = (
        await pool.query(
          `SELECT sleeper_player_id, position, SUM(points) AS pts, COUNT(*) AS starts FROM player_weekly_points
           WHERE team_id = $1 AND season = $2 AND started = true
           GROUP BY sleeper_player_id, position ORDER BY pts DESC LIMIT 30`,
          [team.id, season]
        )
      ).rows.map((r) => ({ name: nameOf(r.sleeper_player_id), position: r.position, points: r1(r.pts), starts: Number(r.starts) }));

      if (!positionBreakdown.length) {
        notes.weekly = 'Re-run "Sync Weekly Scores" once to fill in the position and top-scorer charts.';
      }
    } else {
      notes.weekly = 'No weekly scores yet. Click "Sync Weekly Scores" in the top bar.';
    }

    // ---------- Trades ----------
    // Deliberately NOT filtered by the season dropdown — this is meant to be
    // full multi-year trade history. Each trade carries its own season so the
    // UI can label which year it happened in.
    const myRid = String(team.sleeper_roster_id);
    const tradesRes = await pool.query(
      "SELECT * FROM trades_log WHERE team_id = $1 ORDER BY occurred_at ASC",
      [team.id]
    );
    // Traces a traded pick ("2027 Round 1, originally Ben's") forward to
    // whichever player was actually drafted with it, once that draft has
    // happened. Works even though the pick usually ends up in a different
    // team's hands than either side of the original trade.
    async function resolvePick(p) {
      const orig = ownerByRoster[String(p.roster_id)];
      const label = `${p.season} Round ${p.round}${orig ? ` (${orig}'s)` : ""}`;

      const slotRes = await pool.query(
        "SELECT pick_no FROM draft_slot_map WHERE season = $1 AND round = $2 AND original_roster_id = $3",
        [String(p.season), p.round, String(p.roster_id)]
      );
      if (!slotRes.rows.length) return { label, resolved: false, reason: "draft order not set yet" };

      const pickRes = await pool.query(
        `SELECT dp.player_name, dp.sleeper_player_id, t.owner_name AS drafted_by
         FROM draft_picks dp LEFT JOIN teams t ON t.id = dp.team_id
         WHERE dp.season = $1 AND dp.pick_no = $2`,
        [String(p.season), slotRes.rows[0].pick_no]
      );
      if (!pickRes.rows.length) return { label, resolved: false, reason: "not drafted yet" };

      const row = pickRes.rows[0];
      let points = null;
      if (row.sleeper_player_id) {
        const ptsRes = await pool.query(
          "SELECT COALESCE(SUM(points),0) AS pts FROM player_weekly_points WHERE sleeper_player_id = $1 AND season = $2",
          [row.sleeper_player_id, String(p.season)]
        );
        points = r1(ptsRes.rows[0].pts);
      }
      return { label, resolved: true, playerName: row.player_name, draftedBy: row.drafted_by, seasonPoints: points };
    }

    const trades = [];
    for (const trade of tradesRes.rows) {
      const d = trade.details || {};
      const tradeSeason = trade.season || currentSeason; // older rows synced before the season column existed
      const receivedIds = Object.entries(d.adds || {}).filter(([, r]) => String(r) === myRid).map(([p]) => p);
      const sentIds = Object.entries(d.drops || {}).filter(([, r]) => String(r) === myRid).map(([p]) => p);
      const picks = d.draft_picks || [];
      const picksReceived = [];
      for (const p of picks.filter((p) => String(p.owner_id) === myRid)) picksReceived.push(await resolvePick(p));
      const picksSent = [];
      for (const p of picks.filter((p) => String(p.previous_owner_id) === myRid)) picksSent.push(await resolvePick(p));
      const week = d.leg || 1;

      let pointsReceived = 0;
      let pointsGivenUp = 0;
      let weeksAfter = 0;
      if (receivedIds.length) {
        const r = await pool.query(
          `SELECT COALESCE(SUM(points),0) AS pts, COUNT(DISTINCT week) AS wks FROM player_weekly_points
           WHERE sleeper_player_id = ANY($1::text[]) AND season = $2 AND week >= $3 AND team_id = $4`,
          [receivedIds, tradeSeason, week, team.id]
        );
        pointsReceived = Number(r.rows[0].pts);
        weeksAfter = Number(r.rows[0].wks);
      }
      if (sentIds.length) {
        const r = await pool.query(
          `SELECT COALESCE(SUM(points),0) AS pts FROM player_weekly_points
           WHERE sleeper_player_id = ANY($1::text[]) AND season = $2 AND week >= $3
             AND team_id IS DISTINCT FROM $4`,
          [sentIds, tradeSeason, week, team.id]
        );
        pointsGivenUp = Number(r.rows[0].pts);
      }

      trades.push({
        transactionId: trade.sleeper_transaction_id,
        season: tradeSeason,
        week,
        date: trade.occurred_at,
        playersReceived: receivedIds.map(nameOf),
        playersSent: sentIds.map(nameOf),
        picksReceived,
        picksSent,
        pointsReceived: r1(pointsReceived),
        pointsGivenUp: r1(pointsGivenUp),
        net: r1(pointsReceived - pointsGivenUp),
        avgPerWeekReceived: weeksAfter ? r1(pointsReceived / weeksAfter) : null,
        weeksAfter,
        picksOnly: !receivedIds.length && !sentIds.length,
      });
    }
    if (!trades.length) notes.trades = "No trades involving this team have been recorded yet.";

    // ---------- Keepers ----------
    const keeperRows = [];
    const hist = await pool.query(
      "SELECT player_name, cost FROM keeper_history_2025 WHERE owner_name = $1 AND kept = true",
      [team.owner_name]
    );
    for (const h of hist.rows) {
      const pid = resolvePlayerId(h.player_name, allPlayers);
      keeperRows.push({
        season: "2025",
        playerName: h.player_name,
        playerId: pid,
        position: pid ? allPlayers[pid]?.position : null,
        cost: Number(h.cost),
      });
    }
    const later = await pool.query(
      `SELECT season, player_name, sleeper_player_id, cost
       FROM keeper_seasons
       WHERE team_id = $1 AND kept = true AND season <> '2025' AND season <> $2`,
      [team.id, currentSeason]
    );
    for (const k of later.rows) {
      keeperRows.push({
        season: k.season,
        playerName: k.player_name,
        playerId: k.sleeper_player_id || resolvePlayerId(k.player_name, allPlayers),
        cost: k.cost != null ? Number(k.cost) : null,
      });
    }
    const pending = await pool.query(
      "SELECT sleeper_player_id, player_name, keeper_cost, position FROM roster_entries WHERE team_id = $1 AND is_keeper = true AND is_active_on_sleeper = true",
      [team.id]
    );
    for (const p of pending.rows) {
      keeperRows.push({
        season: currentSeason,
        playerName: p.player_name,
        playerId: p.sleeper_player_id,
        cost: p.keeper_cost != null ? Number(p.keeper_cost) : null,
        position: p.position,
        current: true,
      });
    }

    const keepers = [];
    for (const k of keeperRows) {
      let points = null;
      let weeks = 0;
      let position = k.position || null;
      if (k.playerId) {
        const r = await pool.query(
          `SELECT SUM(points) AS pts, COUNT(*) AS wks, MAX(position) AS pos FROM player_weekly_points
           WHERE sleeper_player_id = $1 AND season = $2 AND (team_id = $3 OR team_id IS NULL)`,
          [k.playerId, k.season, team.id]
        );
        weeks = Number(r.rows[0].wks);
        if (weeks > 0) points = Number(r.rows[0].pts);
        position = position || r.rows[0].pos || allPlayers[k.playerId]?.position || null;
      }
      keepers.push({
        season: k.season,
        playerName: k.playerName,
        position,
        cost: k.cost,
        seasonPoints: points != null ? r1(points) : null,
        weeks,
        pointsPerCost: points != null && k.cost ? r1(points / k.cost) : null,
        current: !!k.current,
      });
    }
    keepers.sort((a, b) => (b.season > a.season ? 1 : b.season < a.season ? -1 : (b.seasonPoints ?? -1) - (a.seasonPoints ?? -1)));
    const keepersAllYears = keepers;
    const keepersFiltered = season ? keepers.filter((k) => k.season === season) : keepers;
    if (!keepersAllYears.length) {
      const anyHistory = await pool.query("SELECT 1 FROM keeper_history_2025 WHERE owner_name = $1 LIMIT 1", [team.owner_name]);
      notes.keepers = anyHistory.rows.length
        ? "No keepers recorded for this team yet."
        : 'This team isn\'t matched to its 2025 history yet. Use "Rename / Match to 2025 History" on this page (it needs the exact house name, like Alec).';
    } else if (!keepersFiltered.length) {
      notes.keepers = `No keepers recorded for ${season} — try a different season above.`;
    } else if (keepersFiltered.every((k) => k.seasonPoints == null)) {
      notes.keepers = 'Keepers found, but no points yet. Click "Sync Weekly Scores" (it now pulls past seasons too).';
    }

    // ---------- Draft ----------
    const pickPoints = await pool.query(
      `SELECT dp.draft_id, dp.pick_no, dp.season, dp.round, dp.team_id, dp.sleeper_player_id, dp.player_name, dp.position,
              (SELECT SUM(p.points) FROM player_weekly_points p WHERE p.sleeper_player_id = dp.sleeper_player_id AND p.season = dp.season) AS pts
       FROM draft_picks dp`
    );
    const roundTotals = {};
    for (const r of pickPoints.rows) {
      if (r.pts == null) continue;
      const key = `${r.season}:${r.round}`;
      roundTotals[key] = roundTotals[key] || { sum: 0, n: 0 };
      roundTotals[key].sum += Number(r.pts);
      roundTotals[key].n++;
    }
    const draft = pickPoints.rows
      .filter((r) => r.team_id === team.id && (!season || r.season === season))
      .map((r) => {
        const rt = roundTotals[`${r.season}:${r.round}`];
        const avg = rt ? rt.sum / rt.n : null;
        const pts = r.pts != null ? Number(r.pts) : null;
        return {
          season: r.season,
          round: r.round,
          pickNo: r.pick_no,
          playerName: r.player_name,
          position: r.position,
          seasonPoints: pts != null ? r1(pts) : null,
          roundAverage: avg != null ? r1(avg) : null,
          vsRound: pts != null && avg != null ? r1(pts - avg) : null,
        };
      })
      .sort((a, b) => (b.season > a.season ? 1 : b.season < a.season ? -1 : a.pickNo - b.pickNo));
    const anyPicksAtAll = pickPoints.rows.some((r) => r.team_id === team.id);
    if (!anyPicksAtAll) {
      notes.draft = 'No draft picks on file for this team. Click "Sync Draft History" (re-run it after this update).';
    } else if (!draft.length) {
      notes.draft = `No draft picks on file for ${season} — try a different season above.`;
    } else if (draft.every((d) => d.seasonPoints == null)) {
      notes.draft = 'Picks found, but no points yet. Click "Sync Weekly Scores" to pull scoring for those seasons.';
    }

    const filteredTop = (posFilter ? topScorers.filter((t) => t.position === posFilter) : topScorers).slice(0, 8);

    res.json({
      seasons,
      season,
      currentSeason,
      kpis,
      weekly,
      positionBreakdown,
      topScorers: filteredTop,
      trades,
      keepers: posFilter ? keepersFiltered.filter((k) => k.position === posFilter) : keepersFiltered,
      draft: posFilter ? draft.filter((d) => d.position === posFilter) : draft,
      availablePositions,
      positionFilter: posFilter || null,
      notes,
    });
  } catch (err) {
    console.error("[analytics]", err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
