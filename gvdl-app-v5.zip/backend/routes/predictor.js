const express = require("express");
const { pool } = require("../db");
const sleeper = require("../sleeper");
const { simulatePlayoffs } = require("../playoffPredictor");
const { predictDraftOrder } = require("../draftPickPredictor");

const router = express.Router();

function requireLeagueId(req, res, next) {
  if (!process.env.SLEEPER_LEAGUE_ID) return res.status(400).json({ error: "SLEEPER_LEAGUE_ID is not set." });
  next();
}

// GET /api/predictor/playoffs
router.get("/playoffs", requireLeagueId, async (req, res) => {
  try {
    const result = await simulatePlayoffs(process.env.SLEEPER_LEAGUE_ID);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/predictor/draft-order
router.get("/draft-order", requireLeagueId, async (req, res) => {
  try {
    const result = await predictDraftOrder(process.env.SLEEPER_LEAGUE_ID);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------- Mock draft ----------

// GET /api/predictor/mock-draft — current order, picks made, and available pool
router.get("/mock-draft", async (req, res) => {
  const orderRow = await pool.query("SELECT value FROM league_settings WHERE key = 'mock_draft_order'");
  const order = orderRow.rows[0]?.value || null;

  const picksRes = await pool.query(
    `SELECT mp.*, t.owner_name FROM mock_draft_picks mp LEFT JOIN teams t ON t.id = mp.team_id ORDER BY pick_no`
  );
  const picks = picksRes.rows;
  const pickedPlayerIds = new Set(picks.map((p) => p.sleeper_player_id));

  let pool_ = [];
  try {
    pool_ = await buildAvailablePool(pickedPlayerIds, req.query.position);
  } catch (err) {
    return res.status(500).json({ error: "Couldn't build the available player pool: " + err.message });
  }

  const onTheClockPick = order ? picks.length + 1 : null;
  const onTheClockTeamId = order && onTheClockPick <= order.length ? order[onTheClockPick - 1] : null;

  res.json({ order, picks, pool: pool_, onTheClockPick, onTheClockTeamId, totalPicks: order?.length || 0 });
});

async function buildAvailablePool(excludeIds, positionFilter) {
  const allPlayers = await sleeper.getAllPlayers();
  const rosteredRes = await pool.query(
    "SELECT sleeper_player_id, is_keeper FROM roster_entries WHERE is_active_on_sleeper = true AND sleeper_player_id IS NOT NULL"
  );
  const rosteredKeeperStatus = new Map(rosteredRes.rows.map((r) => [r.sleeper_player_id, r.is_keeper]));
  const fantasyPositions = new Set(["QB", "RB", "WR", "TE", "K", "DEF"]);

  const out = [];
  for (const [id, p] of Object.entries(allPlayers)) {
    if (excludeIds.has(id)) continue;
    if (!p.position || !fantasyPositions.has(p.position)) continue;
    if (positionFilter && p.position !== positionFilter) continue;

    const isRostered = rosteredKeeperStatus.has(id);
    const isKeptElsewhere = rosteredKeeperStatus.get(id) === true;
    if (isKeptElsewhere) continue; // kept players aren't available

    const isRookie = p.years_exp === 0;
    if (!isRookie && !isRostered) continue; // only rookies + currently-unkept rostered players; true unrostered vets are usually irrelevant/retired in Sleeper's dump

    out.push({
      id,
      name: `${p.first_name || ""} ${p.last_name || ""}`.trim(),
      position: p.position,
      nflTeam: p.team,
      source: isRookie ? "rookie" : "unkept_veteran",
      searchRank: p.search_rank ?? 999999,
    });
  }
  out.sort((a, b) => a.searchRank - b.searchRank);
  return out.slice(0, 300);
}

// POST /api/predictor/mock-draft/start { order: [teamId, teamId, ...] }
router.post("/mock-draft/start", async (req, res) => {
  const { order } = req.body;
  if (!Array.isArray(order) || !order.length) return res.status(400).json({ error: "order must be a non-empty array of team IDs" });
  await pool.query(
    `INSERT INTO league_settings (key, value, updated_at) VALUES ('mock_draft_order', $1, now())
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
    [JSON.stringify(order)]
  );
  await pool.query("DELETE FROM mock_draft_picks");
  res.json({ ok: true });
});

// POST /api/predictor/mock-draft/pick { sleeperPlayerId }
// No PIN gate — this is a shared planning tool, not real roster data.
router.post("/mock-draft/pick", async (req, res) => {
  const { sleeperPlayerId } = req.body;
  const orderRow = await pool.query("SELECT value FROM league_settings WHERE key = 'mock_draft_order'");
  const order = orderRow.rows[0]?.value;
  if (!order) return res.status(400).json({ error: "Mock draft hasn't been started yet." });

  const countRes = await pool.query("SELECT COUNT(*)::int AS n FROM mock_draft_picks");
  const nextPickNo = countRes.rows[0].n + 1;
  if (nextPickNo > order.length) return res.status(400).json({ error: "The mock draft is already complete." });
  const teamId = order[nextPickNo - 1];

  const allPlayers = await sleeper.getAllPlayers();
  const p = allPlayers[sleeperPlayerId];
  if (!p) return res.status(404).json({ error: "Unknown player." });

  const dup = await pool.query("SELECT 1 FROM mock_draft_picks WHERE sleeper_player_id = $1", [sleeperPlayerId]);
  if (dup.rows.length) return res.status(409).json({ error: "That player has already been picked." });

  const isRookie = p.years_exp === 0;
  await pool.query(
    `INSERT INTO mock_draft_picks (pick_no, team_id, sleeper_player_id, player_name, position, source)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [nextPickNo, teamId, sleeperPlayerId, `${p.first_name || ""} ${p.last_name || ""}`.trim(), p.position, isRookie ? "rookie" : "unkept_veteran"]
  );
  res.json({ ok: true, pickNo: nextPickNo });
});

// POST /api/predictor/mock-draft/reset
router.post("/mock-draft/reset", async (req, res) => {
  await pool.query("DELETE FROM mock_draft_picks");
  await pool.query("DELETE FROM league_settings WHERE key = 'mock_draft_order'");
  res.json({ ok: true });
});

module.exports = router;
module.exports.buildAvailablePool = buildAvailablePool;
