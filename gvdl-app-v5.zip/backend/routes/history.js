const express = require("express");
const { pool } = require("../db");

const router = express.Router();

// GET /api/history — full 2025 keeper reference, grouped by owner
router.get("/", async (req, res) => {
  const { rows } = await pool.query(
    "SELECT * FROM keeper_history_2025 ORDER BY owner_name ASC, kept DESC, cost DESC NULLS LAST"
  );
  const grouped = {};
  for (const r of rows) {
    grouped[r.owner_name] = grouped[r.owner_name] || [];
    grouped[r.owner_name].push(r);
  }
  res.json(grouped);
});

// GET /api/history/owners — the 12 distinct owner names from 2025 history,
// each flagged with whether a current team has already claimed that name.
// The frontend uses this to offer a pick-list when renaming a team, instead
// of free text, so a typo can't silently break the history match.
router.get("/owners", async (req, res) => {
  const { rows } = await pool.query(`
    SELECT DISTINCT h.owner_name,
      EXISTS(SELECT 1 FROM teams t WHERE t.owner_name = h.owner_name) AS claimed
    FROM keeper_history_2025 h
    ORDER BY h.owner_name ASC
  `);
  res.json(rows);
});

module.exports = router;
