const express = require("express");
const { pool } = require("../db");
const sleeper = require("../sleeper");

const router = express.Router();
const r1 = (n) => Math.round(Number(n) * 10) / 10;

// Regular-season length this league uses for "remaining weeks" math. The
// playoff_week_start from league settings is the real end of fantasy-relevant
// production (bench points in the owner's own playoffs don't count toward a
// trade's remaining-season value), so remaining weeks = playoffStart - 1 -
// currentWeek, floored at 0.
async function getRemainingWeeks(leagueId) {
  const [state, league] = await Promise.all([sleeper.getState(), sleeper.getLeague(leagueId)]);
  const currentWeek = Number(state.week) || 1;
  const playoffStart = league.settings?.playoff_week_start || 15;
  const lastRelevantWeek = playoffStart - 1;
  const remaining = Math.max(0, lastRelevantWeek - currentWeek);
  return { season: String(league.season), currentWeek, playoffStart, remainingWeeks: remaining };
}

// Real season-to-date scoring pace for one player, projected forward over the
// real remaining weeks of the season. No fabricated trade-value score — just
// (points so far / games played so far) * weeks left.
async function projectPlayer(sleeperPlayerId, season, remainingWeeks) {
  const res = await pool.query(
    "SELECT COALESCE(SUM(points),0) AS pts, COUNT(*) AS games FROM player_weekly_points WHERE sleeper_player_id = $1 AND season = $2",
    [sleeperPlayerId, season]
  );
  const totalPoints = Number(res.rows[0].pts);
  const games = Number(res.rows[0].games);
  const pointsPerGame = games > 0 ? totalPoints / games : 0;
  const projectedRemaining = pointsPerGame * remainingWeeks;
  return {
    sleeperPlayerId,
    season,
    gamesPlayed: games,
    seasonPointsSoFar: r1(totalPoints),
    pointsPerGame: r1(pointsPerGame),
    remainingWeeks,
    projectedRemainingPoints: r1(projectedRemaining),
  };
}

// Flat per-week value assigned to ANY traded pick: the average points-per-game
// put up this season by players actually drafted in round 1 of this year's
// real Sleeper draft. Simple by design (the user asked for exactly this, not a
// round-by-round discount curve) — so a 2nd-rounder and a 2027 1st both carry
// the same rate; the UI labels it clearly so nobody mistakes it for a precise
// forecast of a specific future pick.
async function getRound1PickValue(season) {
  const res = await pool.query(
    `SELECT dp.sleeper_player_id,
            COALESCE(SUM(pwp.points), 0) AS pts,
            COUNT(pwp.week) AS games
     FROM draft_picks dp
     LEFT JOIN player_weekly_points pwp
       ON pwp.sleeper_player_id = dp.sleeper_player_id AND pwp.season = dp.season
     WHERE dp.season = $1 AND dp.round = 1
     GROUP BY dp.sleeper_player_id`,
    [season]
  );
  const rates = res.rows
    .map((r) => ({ pts: Number(r.pts), games: Number(r.games) }))
    .filter((r) => r.games > 0)
    .map((r) => r.pts / r.games);
  const value = rates.length ? rates.reduce((s, v) => s + v, 0) / rates.length : 0;
  return { pointsPerWeek: r1(value), playersConsidered: rates.length };
}

// Resolves a player's display name + whether ANY team currently flags him as
// a keeper (trading a keeper has extra league-rule consequences worth flagging,
// regardless of which side of the trade he's on).
async function playerMeta(sleeperPlayerId, allPlayers) {
  const p = allPlayers[sleeperPlayerId];
  const name = p ? `${p.first_name || ""} ${p.last_name || ""}`.trim() : `Player ${sleeperPlayerId}`;
  const position = p?.position || null;
  const keeperRes = await pool.query(
    "SELECT team_id FROM roster_entries WHERE sleeper_player_id = $1 AND is_keeper = true AND is_active_on_sleeper = true LIMIT 1",
    [sleeperPlayerId]
  );
  return { name, position, isKeeper: !!keeperRes.rows.length };
}

async function buildSide(side, season, remainingWeeks, allPlayers, warnings, label, pickValue) {
  const teamRes = side.teamId
    ? await pool.query("SELECT id, owner_name FROM teams WHERE id = $1", [side.teamId])
    : { rows: [] };
  const teamName = teamRes.rows[0]?.owner_name || null;

  const playerIds = Array.isArray(side.playerIds) ? side.playerIds : [];
  const players = [];
  let total = 0;
  for (const pid of playerIds) {
    const [proj, meta] = await Promise.all([
      projectPlayer(pid, season, remainingWeeks),
      playerMeta(pid, allPlayers),
    ]);
    if (meta.isKeeper) {
      warnings.push(
        `${meta.name} (${label}${teamName ? `, ${teamName}` : ""}) is currently flagged as a keeper — trading a keeper carries the league's extra keeper-trade consequences (see Rules).`
      );
    }
    players.push({
      sleeperPlayerId: pid,
      name: meta.name,
      position: meta.position,
      isKeeper: meta.isKeeper,
      ...proj,
    });
    total += proj.projectedRemainingPoints;
  }

  const rawPicks = Array.isArray(side.picks) ? side.picks : [];
  const picks = rawPicks.map((p) => {
    const projectedRemainingPoints = r1(pickValue.pointsPerWeek * remainingWeeks);
    total += projectedRemainingPoints;
    return {
      season: p.season || null,
      round: p.round || null,
      label: p.label || `${p.season || "Future"} Round ${p.round || "?"}`,
      pointsPerGame: pickValue.pointsPerWeek,
      projectedRemainingPoints,
    };
  });

  return { teamId: side.teamId || null, teamName, players, picks, projectedTotal: r1(total) };
}

// POST /api/trade-analyzer/preview
// body: { sideA: { teamId, playerIds: [] }, sideB: { teamId, playerIds: [] } }
router.post("/preview", async (req, res) => {
  try {
    if (!process.env.SLEEPER_LEAGUE_ID) return res.status(400).json({ error: "SLEEPER_LEAGUE_ID is not set." });
    const { sideA, sideB } = req.body || {};
    if (!sideA || !sideB) return res.status(400).json({ error: "Body must include sideA and sideB." });

    const { season, remainingWeeks, currentWeek, playoffStart } = await getRemainingWeeks(process.env.SLEEPER_LEAGUE_ID);
    const allPlayers = await sleeper.getAllPlayers();
    const warnings = [];
    const pickValue = await getRound1PickValue(season);
    if (!pickValue.playersConsidered) {
      warnings.push(
        `No scored games yet for this year's round-1 picks, so any traded picks are valued at 0 pts/week until those rookies start putting up points.`
      );
    }

    const a = await buildSide(sideA, season, remainingWeeks, allPlayers, warnings, "Side A", pickValue);
    const b = await buildSide(sideB, season, remainingWeeks, allPlayers, warnings, "Side B", pickValue);

    // "pointsGiven" = what that side sends away (their own players + picks'
    // projected value); "pointsReceived" = the projected value of what they
    // get back (i.e. the other side's players + picks).
    const result = {
      season,
      currentWeek,
      playoffStart,
      remainingWeeks,
      pickValuePerWeek: pickValue.pointsPerWeek,
      pickValuePlayersConsidered: pickValue.playersConsidered,
      sideA: {
        teamId: a.teamId,
        teamName: a.teamName,
        players: a.players,
        picks: a.picks,
        pointsGiven: a.projectedTotal,
        pointsReceived: b.projectedTotal,
        net: r1(b.projectedTotal - a.projectedTotal),
      },
      sideB: {
        teamId: b.teamId,
        teamName: b.teamName,
        players: b.players,
        picks: b.picks,
        pointsGiven: b.projectedTotal,
        pointsReceived: a.projectedTotal,
        net: r1(a.projectedTotal - b.projectedTotal),
      },
      warnings,
    };
    res.json(result);
  } catch (err) {
    console.error("[tradeAnalyzer]", err);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/trade-analyzer/pick-value — lets the UI show the current flat
// pick value before anyone builds a trade.
router.get("/pick-value", async (req, res) => {
  try {
    if (!process.env.SLEEPER_LEAGUE_ID) return res.status(400).json({ error: "SLEEPER_LEAGUE_ID is not set." });
    const { season } = await getRemainingWeeks(process.env.SLEEPER_LEAGUE_ID);
    const pickValue = await getRound1PickValue(season);
    res.json({ season, ...pickValue });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
module.exports.projectPlayer = projectPlayer;
module.exports.getRemainingWeeks = getRemainingWeeks;
module.exports.getRound1PickValue = getRound1PickValue;
