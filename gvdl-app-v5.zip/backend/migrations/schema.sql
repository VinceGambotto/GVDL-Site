-- GVSU Franchise League schema

CREATE TABLE IF NOT EXISTS teams (
  id SERIAL PRIMARY KEY,
  owner_name TEXT NOT NULL UNIQUE,
  sleeper_roster_id TEXT UNIQUE,
  sleeper_owner_id TEXT,
  sleeper_display_name TEXT,
  starting_points NUMERIC DEFAULT 20,
  trade_allowance INTEGER,
  pin_hash TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Current-season roster, refreshed by Sleeper sync. Keeper flag/cost is a manual
-- overlay the owner sets themselves (Sleeper has no concept of your keeper rules).
CREATE TABLE IF NOT EXISTS roster_entries (
  id SERIAL PRIMARY KEY,
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  sleeper_player_id TEXT,
  player_name TEXT NOT NULL,
  position TEXT,
  nfl_team TEXT,
  keeper_cost NUMERIC,
  is_keeper BOOLEAN DEFAULT false,
  is_active_on_sleeper BOOLEAN DEFAULT true,
  source TEXT DEFAULT 'sleeper',
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(team_id, sleeper_player_id)
);

-- Read-only reference data seeded once from the 2025 keeper spreadsheet.
CREATE TABLE IF NOT EXISTS keeper_history_2025 (
  id SERIAL PRIMARY KEY,
  owner_name TEXT NOT NULL,
  player_name TEXT NOT NULL,
  position TEXT,
  cost NUMERIC,
  kept BOOLEAN,
  points_remaining NUMERIC,
  points_for_next_year NUMERIC
);

-- Trades pulled from Sleeper's transactions endpoint, so "trades remaining"
-- is allowance minus what actually happened on Sleeper, not a manual counter.
CREATE TABLE IF NOT EXISTS trades_log (
  id SERIAL PRIMARY KEY,
  sleeper_transaction_id TEXT UNIQUE NOT NULL,
  team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
  details JSONB,
  occurred_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS storylines (
  id SERIAL PRIMARY KEY,
  team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
  week INTEGER,
  season INTEGER,
  kind TEXT NOT NULL DEFAULT 'storyline', -- 'storyline' or 'newsletter'
  title TEXT,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sync_log (
  id SERIAL PRIMARY KEY,
  synced_at TIMESTAMPTZ DEFAULT now(),
  status TEXT NOT NULL,
  detail TEXT
);

-- Team-level actual vs. best-possible-lineup points, one row per week.
-- "Best possible" is a greedy near-optimal heuristic (fill exact-position
-- slots with the top scorer at that position, then FLEX/SUPER_FLEX slots
-- with the best remaining eligible players) — not a formally proven optimum,
-- but right in all normal (non-adversarial) scoring situations.
CREATE TABLE IF NOT EXISTS weekly_scores (
  id SERIAL PRIMARY KEY,
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  season TEXT NOT NULL,
  week INTEGER NOT NULL,
  actual_points NUMERIC NOT NULL,
  optimal_points NUMERIC NOT NULL,
  UNIQUE(team_id, season, week)
);

-- Per-player, per-week fantasy points, cached from Sleeper matchup data.
-- Drives trade value, keeper ROI, and draft value analysis.
CREATE TABLE IF NOT EXISTS player_weekly_points (
  sleeper_player_id TEXT NOT NULL,
  season TEXT NOT NULL,
  week INTEGER NOT NULL,
  points NUMERIC NOT NULL,
  PRIMARY KEY (sleeper_player_id, season, week)
);

-- Every roster transaction (trade, waiver, free agent), not just trades —
-- powers the newsletter's "roster moves" section. trades_log stays as-is
-- for the points/trades-remaining feature; this is the broader feed.
CREATE TABLE IF NOT EXISTS transactions_log (
  id SERIAL PRIMARY KEY,
  sleeper_transaction_id TEXT NOT NULL,
  team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  week INTEGER,
  details JSONB,
  occurred_at TIMESTAMPTZ,
  UNIQUE(sleeper_transaction_id, team_id)
);
-- walking the league's draft history (current season + past seasons via
-- Sleeper's previous_league_id chain). Drives automatic keeper cost.
CREATE TABLE IF NOT EXISTS player_draft_rounds (
  sleeper_player_id TEXT PRIMARY KEY,
  round INTEGER NOT NULL,
  season TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- One row per team+player+season a keeper decision was locked in. Used to
-- enforce the 3-consecutive-season keeper cap. 2025 rows are seeded (best
-- effort, matched by player name) when a team is matched to its 2025 history;
-- 2026-onward rows are written by the "Close Season" action.
CREATE TABLE IF NOT EXISTS keeper_seasons (
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  sleeper_player_id TEXT, -- nullable: 2025 seed rows have no Sleeper ID, matched by name only
  player_name TEXT NOT NULL,
  season TEXT NOT NULL,
  kept BOOLEAN NOT NULL,
  PRIMARY KEY (team_id, player_name, season)
);

-- One row per team per season closed out, recording the points math so the
-- rollover into next season is auditable rather than a black box.
CREATE TABLE IF NOT EXISTS season_history (
  id SERIAL PRIMARY KEY,
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  season TEXT NOT NULL,
  starting_points NUMERIC NOT NULL,
  points_used NUMERIC NOT NULL,
  points_remaining NUMERIC NOT NULL,
  rollover_to_next_season NUMERIC NOT NULL,
  closed_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(team_id, season)
);

-- Additive migrations for installs upgrading in place (safe to re-run;
-- a fresh install already has these from the CREATE TABLE statements above).
ALTER TABLE storylines ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'storyline';

-- Analytics upgrades (safe to re-run): remember which team held each player
-- each week, whether he was in the starting lineup, and his position.
ALTER TABLE player_weekly_points ADD COLUMN IF NOT EXISTS team_id INTEGER;
ALTER TABLE player_weekly_points ADD COLUMN IF NOT EXISTS started BOOLEAN DEFAULT false;
ALTER TABLE player_weekly_points ADD COLUMN IF NOT EXISTS position TEXT;

-- Every draft pick each team actually made (all drafts, current + past
-- seasons), for draft analysis. team_id is null if the picker can't be
-- matched to a current team.
CREATE TABLE IF NOT EXISTS draft_picks (
  draft_id TEXT NOT NULL,
  pick_no INTEGER NOT NULL,
  season TEXT NOT NULL,
  round INTEGER NOT NULL,
  team_id INTEGER REFERENCES teams(id) ON DELETE SET NULL,
  sleeper_player_id TEXT NOT NULL,
  player_name TEXT,
  position TEXT,
  PRIMARY KEY (draft_id, pick_no)
);

-- Records the keeper cost that actually applied in that season, so ROI math
-- for past seasons doesn't drift if a team's current cost field changes later.
ALTER TABLE keeper_seasons ADD COLUMN IF NOT EXISTS cost NUMERIC;

-- Every time the master PIN is used to clear a locked-out team's PIN.
-- Shown on the home page as "Recovery Activity" so the commissioner always
-- sees it, with no email/SMS setup required.
CREATE TABLE IF NOT EXISTS recovery_log (
  id SERIAL PRIMARY KEY,
  team_id INTEGER REFERENCES teams(id) ON DELETE SET NULL,
  owner_name TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Filterable-by-year support: trades and transactions need to know which
-- season they happened in, not just a timestamp.
ALTER TABLE trades_log ADD COLUMN IF NOT EXISTS season TEXT;
ALTER TABLE transactions_log ADD COLUMN IF NOT EXISTS season TEXT;

-- Maps a traded future pick (identified by season + round + the ORIGINAL
-- roster it belongs to) to the actual overall pick number in that draft, so
-- a traded pick can be traced forward to whichever player was eventually
-- drafted with it — even though that's usually a different team than either
-- side of the original trade.
CREATE TABLE IF NOT EXISTS draft_slot_map (
  draft_id TEXT NOT NULL,
  season TEXT NOT NULL,
  round INTEGER NOT NULL,
  original_roster_id TEXT NOT NULL,
  pick_no INTEGER NOT NULL,
  PRIMARY KEY (draft_id, round, original_roster_id)
);

-- Generic small key/value store for one-off app state that doesn't need its
-- own table (currently: the mock draft's pick order).
CREATE TABLE IF NOT EXISTS league_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Picks made in the shared mock draft tool. Not real Sleeper data — a
-- planning tool the whole league can use together.
CREATE TABLE IF NOT EXISTS mock_draft_picks (
  pick_no INTEGER PRIMARY KEY,
  team_id INTEGER REFERENCES teams(id) ON DELETE SET NULL,
  sleeper_player_id TEXT NOT NULL,
  player_name TEXT NOT NULL,
  position TEXT,
  source TEXT, -- 'rookie' or 'unkept_veteran'
  picked_at TIMESTAMPTZ DEFAULT now()
);
