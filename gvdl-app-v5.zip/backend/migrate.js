const fs = require("fs");
const path = require("path");
const { pool } = require("./db");

async function run() {
  const schema = fs.readFileSync(path.join(__dirname, "migrations", "schema.sql"), "utf8");
  await pool.query(schema);
  console.log("[migrate] schema applied");

  const { rows } = await pool.query("SELECT COUNT(*)::int AS n FROM keeper_history_2025");
  if (rows[0].n === 0) {
    const seedPath = path.join(__dirname, "migrations", "seed_history_2025.json");
    const seed = JSON.parse(fs.readFileSync(seedPath, "utf8"));
    for (const team of seed) {
      for (const p of team.players) {
        await pool.query(
          `INSERT INTO keeper_history_2025 (owner_name, player_name, position, cost, kept, points_remaining, points_for_next_year)
           VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [team.owner, p.name, p.pos, p.cost, p.kept, team.pointsRemaining, team.pointsForNextYear]
        );
      }
      // Note: we deliberately do NOT create a team row here. Teams are created
      // only by Sleeper sync (sync.js), one per real Sleeper roster. Matching
      // a roster to its house nickname happens afterward via the rename
      // endpoint, which also pulls in the right starting points from this
      // history table — that's what keeps this a single team record instead
      // of a duplicate.
    }
    console.log(`[migrate] seeded 2025 keeper history for ${seed.length} owners`);
  } else {
    console.log("[migrate] history already seeded, skipping");
  }
}

if (require.main === module) {
  run()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("[migrate] failed", err);
      process.exit(1);
    });
}

module.exports = { run };
