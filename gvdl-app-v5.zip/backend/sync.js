const { pool } = require("./db");
const sleeper = require("./sleeper");
const { syncAllSeasonsTransactions } = require("./transactionsSync");

async function runSync() {
  const leagueId = process.env.SLEEPER_LEAGUE_ID;
  if (!leagueId) {
    const msg = "SLEEPER_LEAGUE_ID is not set — skipping sync. Add it to your .env file.";
    console.warn(`[sync] ${msg}`);
    await pool.query("INSERT INTO sync_log (status, detail) VALUES ($1,$2)", ["skipped", msg]);
    return { status: "skipped", detail: msg };
  }

  try {
    const [rosters, users, allPlayers] = await Promise.all([
      sleeper.getRosters(leagueId),
      sleeper.getUsers(leagueId),
      sleeper.getAllPlayers(),
    ]);

    const usersById = Object.fromEntries(users.map((u) => [u.user_id, u]));

    // 1. Upsert one team row per Sleeper roster.
    //    owner_name defaults to the Sleeper display name the first time we see
    //    a roster, but never overwrites a name the commissioner already set —
    //    your house nicknames ("Alec", "Ben"...) don't have to match Sleeper accounts.
    for (const roster of rosters) {
      const user = usersById[roster.owner_id];
      const displayName = user ? (user.metadata?.team_name || user.display_name) : `Roster ${roster.roster_id}`;

      await pool.query(
        `INSERT INTO teams (owner_name, sleeper_roster_id, sleeper_owner_id, sleeper_display_name)
         VALUES ($1,$2,$3,$4)
         ON CONFLICT (sleeper_roster_id) DO UPDATE
           SET sleeper_owner_id = EXCLUDED.sleeper_owner_id,
               sleeper_display_name = EXCLUDED.sleeper_display_name,
               updated_at = now()`,
        [displayName, String(roster.roster_id), roster.owner_id, user?.display_name || null]
      );
    }

    // 2. Upsert roster entries (current players), preserving any manual
    //    keeper flag/cost already set on a player who's still on the roster.
    for (const roster of rosters) {
      const teamRes = await pool.query(
        "SELECT id FROM teams WHERE sleeper_roster_id = $1",
        [String(roster.roster_id)]
      );
      const teamId = teamRes.rows[0]?.id;
      if (!teamId) continue;

      const currentPlayerIds = new Set((roster.players || []).map(String));

      for (const playerId of currentPlayerIds) {
        const p = allPlayers[playerId];
        const name = p ? `${p.first_name || ""} ${p.last_name || ""}`.trim() : `Player ${playerId}`;
        const position = p?.position || null;
        const nflTeam = p?.team || null;

        await pool.query(
          `INSERT INTO roster_entries (team_id, sleeper_player_id, player_name, position, nfl_team, source, is_active_on_sleeper, updated_at)
           VALUES ($1,$2,$3,$4,$5,'sleeper', true, now())
           ON CONFLICT (team_id, sleeper_player_id) DO UPDATE
             SET player_name = EXCLUDED.player_name,
                 position = EXCLUDED.position,
                 nfl_team = EXCLUDED.nfl_team,
                 is_active_on_sleeper = true,
                 updated_at = now()`,
          [teamId, playerId, name, position, nflTeam]
        );
      }

      // Players no longer on the Sleeper roster: mark inactive rather than
      // deleting, so a keeper cost the owner already set isn't lost if it
      // was a temporary drop/re-add.
      await pool.query(
        `UPDATE roster_entries
         SET is_active_on_sleeper = false, updated_at = now()
         WHERE team_id = $1
           AND source = 'sleeper'
           AND sleeper_player_id IS NOT NULL
           AND NOT (sleeper_player_id = ANY($2::text[]))`,
        [teamId, Array.from(currentPlayerIds)]
      );
    }

    // 3. Transactions (trades, waivers, free agents) across current AND past
    //    seasons — a single season's league_id only ever has that season's
    //    data, so this has to walk the whole chain to see prior-year trades.
    const txResult = await syncAllSeasonsTransactions(leagueId);

    const detail = `Synced ${rosters.length} rosters, ${txResult.totalTrades} trade transactions across ${txResult.seasonsWalked.length} season(s) (${txResult.newTrades} new).`;
    await pool.query("INSERT INTO sync_log (status, detail) VALUES ($1,$2)", ["ok", detail]);
    console.log(`[sync] ${detail}`);
    return { status: "ok", detail };
  } catch (err) {
    console.error("[sync] failed", err);
    await pool.query("INSERT INTO sync_log (status, detail) VALUES ($1,$2)", ["error", err.message]);
    return { status: "error", detail: err.message };
  }
}

module.exports = { runSync };
