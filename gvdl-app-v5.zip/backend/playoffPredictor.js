const { pool } = require("./db");
const sleeper = require("./sleeper");

const PLAYOFF_SPOTS = 6;
const ITERATIONS = 3000;

// Box-Muller: samples one value from a normal distribution with the given
// mean/stddev. Scores are clamped at 0 — a fantasy team can't score negative.
function sampleNormal(mean, stddev) {
  if (!stddev || stddev <= 0) return mean;
  const u1 = Math.random() || 1e-9;
  const u2 = Math.random();
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  return Math.max(0, mean + z * stddev);
}

function mean(arr) {
  return arr.length ? arr.reduce((s, v) => s + v, 0) / arr.length : 0;
}
function stddev(arr, avg) {
  if (arr.length < 2) return arr.length ? avg * 0.15 : 10; // not enough games yet: assume mild variance
  const variance = arr.reduce((s, v) => s + (v - avg) ** 2, 0) / (arr.length - 1);
  return Math.sqrt(variance);
}

/**
 * Monte Carlo playoff simulation using each team's current record plus their
 * actual scoring average/consistency so far, simulated against their real
 * remaining schedule. Ties are broken by total points for, matching the
 * common fantasy convention (your league's rules don't specify a tiebreaker,
 * so this is the standard assumption, not a confirmed house rule).
 */
async function simulatePlayoffs(leagueId) {
  const league = await sleeper.getLeague(leagueId);
  const state = await sleeper.getState();
  const currentWeek = Number(state.week) || 1;
  const playoffStart = league.settings?.playoff_week_start || 15;

  const rosters = await sleeper.getRosters(leagueId);
  const teamsRes = await pool.query("SELECT id, owner_name, sleeper_roster_id, sleeper_owner_id FROM teams WHERE sleeper_roster_id IS NOT NULL");
  const teamByRoster = Object.fromEntries(teamsRes.rows.map((t) => [t.sleeper_roster_id, t]));

  // Current record + a scoring profile (mean/stddev) built from this team's
  // actual weekly scores so far this season.
  const teamState = {};
  for (const roster of rosters) {
    const team = teamByRoster[String(roster.roster_id)];
    if (!team) continue;
    const scoresRes = await pool.query(
      "SELECT actual_points FROM weekly_scores WHERE team_id = $1 AND season = $2 ORDER BY week",
      [team.id, String(league.season)]
    );
    const points = scoresRes.rows.map((r) => Number(r.actual_points));
    const avg = mean(points) || Number(roster.settings?.fpts || 0) / Math.max(1, points.length || 1);
    teamState[team.id] = {
      teamId: team.id,
      ownerName: team.owner_name,
      rosterId: String(roster.roster_id),
      wins: Number(roster.settings?.wins || 0),
      losses: Number(roster.settings?.losses || 0),
      ties: Number(roster.settings?.ties || 0),
      pointsFor: Number(roster.settings?.fpts || 0) + Number(roster.settings?.fpts_decimal || 0) / 100,
      scoreMean: avg || 100,
      scoreStd: stddev(points, avg || 100),
      gamesPlayed: points.length,
    };
  }

  // Real remaining schedule, from Sleeper's own matchup pairings.
  const remainingWeeks = [];
  for (let week = currentWeek + (teamsRes.rows.length ? 0 : 1); week < playoffStart; week++) {
    if (week <= currentWeek) continue; // already played
    let matchups;
    try {
      matchups = await sleeper.getMatchups(leagueId, week);
    } catch (err) {
      continue;
    }
    if (!matchups || !matchups.length) continue;
    const byMatchup = {};
    for (const m of matchups) {
      byMatchup[m.matchup_id] = byMatchup[m.matchup_id] || [];
      byMatchup[m.matchup_id].push(String(m.roster_id));
    }
    const pairs = Object.values(byMatchup)
      .filter((rids) => rids.length === 2)
      .map(([a, b]) => [teamByRoster[a]?.id, teamByRoster[b]?.id])
      .filter(([a, b]) => a && b);
    if (pairs.length) remainingWeeks.push(pairs);
  }

  const teamIds = Object.keys(teamState).map(Number);
  const playoffCount = Object.fromEntries(teamIds.map((id) => [id, 0]));
  const rankSum = Object.fromEntries(teamIds.map((id) => [id, 0]));

  for (let iter = 0; iter < ITERATIONS; iter++) {
    const sim = {};
    for (const id of teamIds) sim[id] = { ...teamState[id] };

    for (const weekPairs of remainingWeeks) {
      for (const [a, b] of weekPairs) {
        if (!sim[a] || !sim[b]) continue;
        const scoreA = sampleNormal(sim[a].scoreMean, sim[a].scoreStd);
        const scoreB = sampleNormal(sim[b].scoreMean, sim[b].scoreStd);
        sim[a].pointsFor += scoreA;
        sim[b].pointsFor += scoreB;
        if (scoreA > scoreB) sim[a].wins++;
        else if (scoreB > scoreA) sim[b].wins++;
        else { sim[a].ties++; sim[b].ties++; }
      }
    }

    const ranked = teamIds
      .map((id) => sim[id])
      .sort((x, y) => y.wins - x.wins || y.pointsFor - x.pointsFor);

    ranked.forEach((t, idx) => {
      rankSum[t.teamId] += idx + 1;
      if (idx < PLAYOFF_SPOTS) playoffCount[t.teamId]++;
    });
  }

  const teams = teamIds
    .map((id) => ({
      teamId: id,
      ownerName: teamState[id].ownerName,
      record: `${teamState[id].wins}-${teamState[id].losses}${teamState[id].ties ? `-${teamState[id].ties}` : ""}`,
      pointsFor: Math.round(teamState[id].pointsFor * 10) / 10,
      scoreMean: Math.round(teamState[id].scoreMean * 10) / 10,
      scoreStd: Math.round(teamState[id].scoreStd * 10) / 10,
      playoffOdds: Math.round((playoffCount[id] / ITERATIONS) * 1000) / 10,
      avgFinishRank: Math.round((rankSum[id] / ITERATIONS) * 10) / 10,
    }))
    .sort((a, b) => a.avgFinishRank - b.avgFinishRank);

  return {
    season: league.season,
    currentWeek,
    playoffWeekStart: playoffStart,
    remainingWeeksSimulated: remainingWeeks.length,
    iterations: ITERATIONS,
    teams,
  };
}

module.exports = { simulatePlayoffs };
