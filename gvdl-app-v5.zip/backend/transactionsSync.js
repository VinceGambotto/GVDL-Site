const { pool } = require("./db");
const sleeper = require("./sleeper");

// Walks the CURRENT + PAST seasons (via previous_league_id) and records every
// transaction. Sleeper's transaction endpoint only ever answers for the
// league_id you ask it about, and a new league_id is created each season —
// so a season sync that only asks about the current league_id, as the
// original version did, permanently misses every prior year's trades.
async function syncAllSeasonsTransactions(leagueId, { maxSeasons = 6 } = {}) {
  const chain = await sleeper.getLeagueSeasonChain(leagueId, maxSeasons);

  const teamsRes = await pool.query("SELECT id, sleeper_owner_id FROM teams WHERE sleeper_owner_id IS NOT NULL");
  const teamIdByOwner = Object.fromEntries(teamsRes.rows.map((t) => [t.sleeper_owner_id, t.id]));

  let totalTrades = 0;
  let newTrades = 0;
  let totalTxns = 0;
  const seasonsWalked = [];

  for (const league of chain) {
    const season = String(league.season);
    let rosters = [];
    try {
      rosters = await sleeper.getRosters(league.league_id);
    } catch (err) {
      console.warn(`[transactions] rosters for ${season} unavailable: ${err.message}`);
      continue;
    }
    // roster_id -> team_id, specific to this season (roster_ids aren't stable
    // across seasons, but the owner behind them is).
    const teamIdByRoster = {};
    for (const r of rosters) {
      const tid = teamIdByOwner[r.owner_id];
      if (tid) teamIdByRoster[String(r.roster_id)] = tid;
    }

    let seasonTradeCount = 0;
    for (let week = 1; week <= 18; week++) {
      let txns;
      try {
        txns = await sleeper.getTransactions(league.league_id, week);
      } catch (err) {
        continue; // an unplayed week is normal, not an error
      }
      for (const t of txns) {
        if (t.status !== "complete") continue;
        const rosterIds = t.roster_ids || [];
        if (t.type === "trade") { totalTrades++; seasonTradeCount++; }
        totalTxns++;

        for (const rosterId of rosterIds) {
          const teamId = teamIdByRoster[String(rosterId)];
          if (!teamId) continue;

          await pool.query(
            `INSERT INTO transactions_log (sleeper_transaction_id, team_id, type, week, season, details, occurred_at)
             VALUES ($1,$2,$3,$4,$5,$6,to_timestamp($7/1000.0))
             ON CONFLICT (sleeper_transaction_id, team_id) DO UPDATE SET season = EXCLUDED.season`,
            [t.transaction_id, teamId, t.type, week, season, JSON.stringify(t), t.status_updated || t.created]
          );

          if (t.type === "trade") {
            const txnKey = `${season}:${t.transaction_id}:${rosterId}`;
            const res = await pool.query(
              `INSERT INTO trades_log (sleeper_transaction_id, team_id, season, details, occurred_at)
               VALUES ($1,$2,$3,$4,to_timestamp($5/1000.0))
               ON CONFLICT (sleeper_transaction_id) DO UPDATE SET season = EXCLUDED.season
               RETURNING (xmax = 0) AS inserted`,
              [txnKey, teamId, season, JSON.stringify(t), t.status_updated || t.created]
            );
            if (res.rows[0]?.inserted) newTrades++;
          }
        }
      }
    }
    seasonsWalked.push({ season, trades: seasonTradeCount });
  }

  return { totalTrades, newTrades, totalTxns, seasonsWalked };
}

module.exports = { syncAllSeasonsTransactions };
