const API = "/api";
let currentTeam = null;
let sessionToken = null; // in-memory only; lost on refresh, same as before but now it's real auth
let eligibilityByRosterId = {};

async function autofillCosts() {
  if (!canEdit()) { alert("Unlock this team with its PIN first."); return; }
  try {
    const result = await api(`/teams/${currentTeam.id}/autofill-costs`, { method: "POST" });
    if (result.note) alert(result.note);
    const t = await api(`/teams/${currentTeam.id}`);
    currentTeam = t;
    renderRosterTable();
    renderStats();
  } catch (err) {
    alert(err.message);
  }
}

async function closeSeason() {
  if (!canEdit()) { alert("Unlock this team with its PIN first."); return; }
  const season = prompt("Which season are you closing out? (e.g. 2026)", new Date().getFullYear());
  if (!season) return;
  if (!confirm(
    `This locks in ${currentTeam.players.filter(p=>p.is_keeper).length} keeper(s) for ${season} (used for next year's 3-season cap) ` +
    `and rolls unused points into next season. This can be re-run for the same season if something changes, but do this once your keepers are final. Continue?`
  )) return;

  try {
    const result = await api(`/teams/${currentTeam.id}/close-season`, {
      method: "POST", body: JSON.stringify({ season: String(season) })
    });
    alert(
      `Season ${season} closed.\nPoints used: ${result.pointsUsed}\nPoints remaining: ${result.pointsRemaining}\n` +
      `${season} starting points were ${currentTeam.startingPoints}; next season starts at ${result.nextSeasonStartingPoints} points.`
    );
    const t = await api(`/teams/${currentTeam.id}`);
    currentTeam = t;
    renderStats();
  } catch (err) {
    alert(err.message);
  }
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (sessionToken) headers.Authorization = `Bearer ${sessionToken}`;
  const res = await fetch(API + path, { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

// ---------- Home ----------
async function buildGrid() {
  const grid = document.getElementById("teamGrid");
  grid.innerHTML = "<div class='empty-note'>Loading teams…</div>";
  let teams;
  try {
    teams = await api("/teams");
  } catch (err) {
    grid.innerHTML = `<div class="empty-note">Couldn't load teams: ${escapeHtml(err.message)}</div>`;
    return;
  }

  document.getElementById("teamCount").textContent = teams.length;
  document.getElementById("teamsSetCount").textContent =
    teams.filter(t => t.players.some(p => p.is_keeper)).length + "/" + teams.length;

  grid.innerHTML = "";
  teams.forEach(t => grid.appendChild(renderTeamCard(t)));
}

function renderTeamCard(t) {
  const card = document.createElement("div");
  card.className = "team-card";
  card.onclick = () => openTeam(t.id);

  const keepers = t.players.filter(p => p.is_keeper).slice(0, 4);
  const tagsHtml = keepers.length
    ? keepers.map(p => `<span class="tag">${escapeHtml(p.player_name)} &middot; ${p.keeper_cost ?? "?"}</span>`).join("")
    : `<span class="tag ghost">No keepers marked yet</span>`;

  card.innerHTML = `
    <div class="tc-top">
      <div class="tc-name">${escapeHtml(t.ownerName)}${t.hasPin ? '<span class="tc-lock">&#128274;</span>' : ''}</div>
    </div>
    <div class="tc-stats">
      <div class="tc-stat"><div class="num">${t.pointsRemaining}</div><div class="label">Pts Left</div></div>
      <div class="tc-stat"><div class="num">${t.tradesRemaining ?? "&ndash;"}</div><div class="label">Trades Left</div></div>
      <div class="tc-stat"><div class="num">${t.players.length}</div><div class="label">Players</div></div>
    </div>
    <div class="tc-keepers">${tagsHtml}</div>
    <div class="tc-foot"><span>Tap to edit</span><span class="arrow">&rarr;</span></div>
  `;
  return card;
}

function showHome() {
  document.getElementById("teamView").classList.remove("active");
  document.getElementById("rulesView").classList.remove("active");
  document.getElementById("predictorView").classList.remove("active");
  document.getElementById("tradeAnalyzerView").classList.remove("active");
  document.getElementById("homeView").classList.remove("hidden");
  currentTeam = null;
  sessionToken = null;
  buildGrid();
loadNewsletters();
loadRecoveryLog();
}

function showRules() {
  document.getElementById("homeView").classList.add("hidden");
  document.getElementById("teamView").classList.remove("active");
  document.getElementById("predictorView").classList.remove("active");
  document.getElementById("tradeAnalyzerView").classList.remove("active");
  document.getElementById("rulesView").classList.add("active");
}

function showPredictor() {
  document.getElementById("homeView").classList.add("hidden");
  document.getElementById("teamView").classList.remove("active");
  document.getElementById("rulesView").classList.remove("active");
  document.getElementById("tradeAnalyzerView").classList.remove("active");
  document.getElementById("predictorView").classList.add("active");
  loadPlayoffOdds();
  loadDraftOrder();
  loadMockDraft();
}

function showTradeAnalyzer() {
  document.getElementById("homeView").classList.add("hidden");
  document.getElementById("teamView").classList.remove("active");
  document.getElementById("rulesView").classList.remove("active");
  document.getElementById("predictorView").classList.remove("active");
  document.getElementById("tradeAnalyzerView").classList.add("active");
  loadTradeTeams();
}

async function triggerSync() {
  const status = document.getElementById("syncStatus");
  status.textContent = "Syncing…";
  try {
    const result = await api("/sync", { method: "POST" });
    status.textContent = result.status === "ok" ? "Synced just now" : result.detail;
  } catch (err) {
    status.textContent = "Sync failed: " + err.message;
  }
  buildGrid();
loadNewsletters();
  if (currentTeam) openTeam(currentTeam.id);
}

// ---------- Team detail ----------
async function triggerDraftSync() {
  const status = document.getElementById("syncStatus");
  status.textContent = "Reading draft history (can take a minute)…";
  try {
    const result = await api("/sync/drafts", { method: "POST" });
    status.textContent = `Draft history synced: ${result.playersRecorded} players, ${result.seasonsWalked} season(s)`;
  } catch (err) {
    status.textContent = "Draft sync failed: " + err.message;
  }
}

function resetAnalyticsPanel() {
  // Switching teams without this left the PREVIOUS team's charts, KPI cards,
  // and tables visible until "Load Analytics" was clicked again — easy to
  // mistake for one owner seeing another owner's numbers. Charts especially
  // needed an explicit destroy(); clearing innerHTML alone doesn't do it for
  // a canvas-based chart library.
  document.getElementById("analyticsBody").style.display = "none";
  Object.keys(charts).forEach((id) => { charts[id].destroy(); delete charts[id]; });
  ["anKpis", "anTrades", "anKeepers", "anDraft"].forEach((id) => { document.getElementById(id).innerHTML = ""; });
  ["cardWeekly", "cardBench", "cardPos", "cardTop", "cardTrade", "cardKeeper", "cardDraft"].forEach((id) => {
    document.getElementById(id).style.display = "none";
  });
  const seasonSel = document.getElementById("anSeason");
  const posSel = document.getElementById("anPosition");
  seasonSel.innerHTML = "";
  seasonSel.dataset.filled = "";
  posSel.value = "";
}

async function openTeam(id) {
  document.getElementById("homeView").classList.add("hidden");
  document.getElementById("rulesView").classList.remove("active");
  document.getElementById("predictorView").classList.remove("active");
  document.getElementById("tradeAnalyzerView").classList.remove("active");
  document.getElementById("teamView").classList.add("active");
  sessionToken = null;
  resetAnalyticsPanel();

  const t = await api(`/teams/${id}`);
  currentTeam = t;

  document.getElementById("tvName").textContent = t.ownerName;
  document.getElementById("tvSubtitle").textContent = `Starting points: ${t.startingPoints}`;

  try {
    const eligibility = await api(`/teams/${id}/keeper-eligibility`);
    eligibilityByRosterId = Object.fromEntries(eligibility.map(e => [e.rosterEntryId, e]));
  } catch (err) {
    eligibilityByRosterId = {};
  }

  renderLockUI();
  renderRosterTable();
  renderStats();
  renderHistory(t);
}

function canEdit() {
  return !!sessionToken;
}

function renderLockUI() {
  const btn = document.getElementById("lockBtn");
  const banner = document.getElementById("lockBanner");

  if (!currentTeam.hasPin) {
    btn.className = "btn lock-btn state-none";
    btn.innerHTML = "&#128275; Set a PIN to protect this team";
    banner.style.display = "none";
  } else if (canEdit()) {
    btn.className = "btn lock-btn state-unlocked";
    btn.innerHTML = "&#128275; Unlocked &mdash; tap to lock";
    banner.style.display = "none";
  } else {
    btn.className = "btn lock-btn state-locked";
    btn.innerHTML = "&#128274; Locked &mdash; tap to unlock";
    banner.style.display = "flex";
  }
}

async function handleRenameClick() {
  if (!canEdit()) {
    alert("Unlock this team with its PIN first (or set one if it doesn't have one yet), then rename it.");
    return;
  }
  let owners;
  try {
    owners = await api("/history/owners");
  } catch (err) {
    alert("Couldn't load 2025 history names: " + err.message);
    return;
  }
  const unclaimed = owners.filter(o => !o.claimed).map(o => o.owner_name);
  const list = unclaimed.length
    ? `Available 2025 names: ${unclaimed.join(", ")}`
    : "All 12 historical names are already claimed by a team.";
  const name = prompt(
    `Rename this team to match its 2025 house nickname.\n${list}\n\nType the exact name (or any name you want if not matching history):`,
    currentTeam.ownerName
  );
  if (!name) return;

  try {
    const result = await api(`/teams/${currentTeam.id}/name`, {
      method: "PUT", body: JSON.stringify({ ownerName: name })
    });
    currentTeam.ownerName = name;
    if (result.matchedHistory) {
      currentTeam.startingPoints = result.startingPoints;
      alert(`Matched to 2025 history — starting points set to ${result.startingPoints}.`);
    }
    document.getElementById("tvName").textContent = name;
    document.getElementById("tvSubtitle").textContent = `Starting points: ${currentTeam.startingPoints}`;
    const t = await api(`/teams/${currentTeam.id}`);
    currentTeam = { ...t, ownerName: name };
    renderStats();
    renderHistory(currentTeam);
  } catch (err) {
    alert(err.message);
  }
}

async function handleLockClick() {
  if (!currentTeam.hasPin) {
    const pin = prompt(`Set a PIN for ${currentTeam.ownerName}'s team.\nMust be exactly 4 digits, and different from every other team's PIN:`);
    if (!pin) return;
    try {
      const { token } = await api(`/teams/${currentTeam.id}/pin`, {
        method: "POST", body: JSON.stringify({ pin })
      });
      sessionToken = token;
      currentTeam.hasPin = true;
      renderLockUI(); renderRosterTable(); renderStats();
    } catch (err) { alert(err.message); }
    return;
  }

  if (canEdit()) {
    sessionToken = null;
    renderLockUI(); renderRosterTable(); renderStats();
    return;
  }

  const pin = prompt(`Enter the PIN for ${currentTeam.ownerName}'s team:`);
  if (pin === null) return;
  try {
    const { token } = await api(`/teams/${currentTeam.id}/unlock`, {
      method: "POST", body: JSON.stringify({ pin })
    });
    sessionToken = token;
    renderLockUI(); renderRosterTable(); renderStats();
  } catch (err) { alert(err.message); }
}

async function handleForgotPin() {
  const master = prompt(`Locked out of ${currentTeam.ownerName}'s team?\nEnter the commissioner's master code to clear this team's PIN so a new one can be set:`);
  if (!master) return;
  try {
    await api(`/teams/${currentTeam.id}/recover`, { method: "POST", body: JSON.stringify({ masterPin: master }) });
    currentTeam.hasPin = false;
    alert("PIN cleared. You can set a new PIN for this team now.");
    renderLockUI(); renderRosterTable(); renderStats();
  } catch (err) {
    alert(err.message);
  }
}

function renderRosterTable() {
  const body = document.getElementById("rosterBody");
  const empty = document.getElementById("emptyNote");
  body.innerHTML = "";

  if (!currentTeam.players.length) {
    empty.style.display = "block";
    return;
  }
  empty.style.display = "none";

  const locked = !canEdit();
  const dis = locked ? "disabled" : "";

  currentTeam.players.forEach(p => {
    const tr = document.createElement("tr");
    const elig = eligibilityByRosterId[p.id];
    const warn = elig && !elig.eligibleToKeep
      ? `<span title="Kept ${elig.consecutivePriorSeasons} consecutive seasons already — a 3-season cap applies" style="color:var(--rust); margin-left:6px;">&#9888;</span>`
      : "";
    tr.innerHTML = `
      <td>${escapeHtml(p.player_name)}${warn}</td>
      <td><span class="pos-pill">${p.position || "-"}</span></td>
      <td><input class="cost-input" ${dis} type="number" min="0" max="8" value="${p.keeper_cost ?? ""}" data-id="${p.id}" data-field="cost"></td>
      <td style="text-align:center;"><input class="kept-check" ${dis} type="checkbox" ${p.is_keeper ? "checked" : ""} data-id="${p.id}" data-field="kept"></td>
    `;
    body.appendChild(tr);
  });

  document.getElementById("saveKeepersBtn").disabled = locked;
}

async function saveKeepers() {
  if (!canEdit()) return;
  const rows = document.querySelectorAll("#rosterBody tr");
  const entries = [];
  rows.forEach(tr => {
    const costInput = tr.querySelector('[data-field="cost"]');
    const keptInput = tr.querySelector('[data-field="kept"]');
    entries.push({
      id: Number(costInput.dataset.id),
      keeperCost: costInput.value === "" ? null : Number(costInput.value),
      isKeeper: keptInput.checked,
    });
  });

  try {
    await api(`/teams/${currentTeam.id}/keepers`, { method: "PUT", body: JSON.stringify({ entries }) });
    const status = document.getElementById("saveStatus");
    status.classList.add("show");
    setTimeout(() => status.classList.remove("show"), 1400);
    const t = await api(`/teams/${currentTeam.id}`);
    currentTeam = t;
    renderStats();
  } catch (err) {
    alert(err.message);
  }
}

function renderStats() {
  const keepers = currentTeam.players.filter(p => p.is_keeper);
  const used = keepers.reduce((s, p) => s + Number(p.keeper_cost || 0), 0);
  const remaining = currentTeam.startingPoints - used;

  document.getElementById("ptsRemaining").textContent = remaining;
  document.getElementById("ptsRemaining").className = "value" + (remaining < 0 ? " rust" : "");
  document.getElementById("ptsRemainingSub").textContent = `of ${currentTeam.startingPoints} starting points`;
  document.getElementById("ptsUsed").textContent = used;
  document.getElementById("keeperCountSub").textContent = keepers.length + " keeper" + (keepers.length === 1 ? "" : "s");

  const tradesUsed = (currentTeam.trades || []).length;
  const allowance = currentTeam.tradeAllowance;
  const tEl = document.getElementById("tradesRemaining");
  if (allowance == null) {
    tEl.textContent = "—";
    tEl.className = "value";
    document.getElementById("tradesSub").textContent = `${tradesUsed} trades made, no allowance set`;
  } else {
    const left = allowance - tradesUsed;
    tEl.textContent = left;
    tEl.className = "value" + (left <= 0 ? " rust" : " turf");
    document.getElementById("tradesSub").textContent = `${tradesUsed} of ${allowance} used`;
  }
}

async function editAllowance() {
  if (!canEdit()) { alert("Unlock this team with its PIN first."); return; }
  const val = prompt("Set this team's trade allowance for the season:", currentTeam.tradeAllowance ?? "5");
  if (val === null) return;
  const n = Number(val);
  if (isNaN(n) || n < 0) return;
  try {
    await api(`/teams/${currentTeam.id}/trade-allowance`, { method: "PUT", body: JSON.stringify({ allowance: n }) });
    currentTeam.tradeAllowance = n;
    renderStats();
  } catch (err) { alert(err.message); }
}

function toggleHistory() {
  document.getElementById("historyBody").classList.toggle("open");
  document.getElementById("historyChev").classList.toggle("open");
}

function renderHistory(t) {
  const hist = t.history2025 || [];
  document.getElementById("historySub").textContent =
    `${hist.length} players · ${hist.filter(p => p.kept).length} kept in 2025`;
  document.getElementById("historyList").innerHTML = hist.map(p => `
    <li>
      <span>${p.kept ? '<span class="tag">Kept</span> ' : ''}${escapeHtml(p.player_name)} <span class="pos-pill">${p.position || ""}</span></span>
      <span class="pcost">${p.cost} pt${p.cost === 1 ? "" : "s"}</span>
    </li>
  `).join("");
}


// ---------- Weekly scores sync ----------
async function triggerWeeklySync() {
  const status = document.getElementById("syncStatus");
  status.textContent = "Pulling weekly scores (first run reads past seasons too)…";
  try {
    const r = await api("/sync/weekly-scores", { method: "POST" });
    status.textContent = "Weekly scores synced: " + r.summary;
  } catch (err) {
    status.textContent = "Weekly sync failed: " + err.message;
  }
  loadLeagueAnalytics();
}

// ---------- Charts ----------
const GOLD = "#f5b942", BLUE = "#3b82f6", ROYAL = "#0045b6", SILVER = "#b9c0cc", RUST = "#d1583f", TURF = "#4a9d6e";
const POS_COLORS = { QB: GOLD, RB: BLUE, WR: SILVER, TE: "#6fd3c4", K: "#a78bfa", DEF: RUST };
if (window.Chart) {
  Chart.defaults.color = "#a9bcdb";
  Chart.defaults.borderColor = "#16264d";
  Chart.defaults.font.family = "Inter, sans-serif";
}
const charts = {};
function mkChart(id, cfg) {
  if (charts[id]) charts[id].destroy();
  cfg.options = Object.assign({ maintainAspectRatio: false }, cfg.options || {});
  charts[id] = new Chart(document.getElementById(id), cfg);
}
function showCard(cardId, show) {
  document.getElementById(cardId).style.display = show ? "" : "none";
}
function chartTitle(text) {
  return { display: true, text, color: "#f5f7fa", font: { size: 13 } };
}
const fmt = (v) => (v == null ? "&ndash;" : v);
const signed = (v) => (v == null ? "&ndash;" : `<span class="${v >= 0 ? "pos" : "neg"}">${v > 0 ? "+" : ""}${v}</span>`);

function anTable(headers, rows, note, numFrom = 2) {
  if (!rows.length) return `<div class="an-note">${escapeHtml(note || "Nothing to show yet.")}</div>`;
  return (note ? `<div class="an-note">${escapeHtml(note)}</div>` : "") +
    `<div style="overflow-x:auto;"><table class="an-table"><thead><tr>${headers.map(h => `<th>${h}</th>`).join("")}</tr></thead><tbody>${
      rows.map(r => `<tr>${r.map((c, i) => `<td class="${i >= numFrom ? "num" : ""}">${c}</td>`).join("")}</tr>`).join("")
    }</tbody></table></div>`;
}

// ---------- Team analytics ----------
async function loadAnalytics() {
  const body = document.getElementById("analyticsBody");
  body.style.display = "block";
  const errEl = document.getElementById("anError");
  errEl.style.display = "none";

  const seasonSel = document.getElementById("anSeason");
  const posSel = document.getElementById("anPosition");
  const params = new URLSearchParams();
  if (seasonSel.value) params.set("season", seasonSel.value);
  if (posSel.value) params.set("position", posSel.value);

  let d;
  try {
    d = await api(`/teams/${currentTeam.id}/analytics?${params.toString()}`);
  } catch (err) {
    errEl.style.display = "block";
    errEl.textContent = "Couldn't load analytics: " + err.message;
    return;
  }

  seasonSel.parentElement.parentElement.style.display = d.seasons.length ? "" : "none";
  if (!seasonSel.dataset.filled || seasonSel.dataset.filled !== d.seasons.join(",")) {
    seasonSel.innerHTML = d.seasons.map(s => `<option value="${s}" ${s === d.season ? "selected" : ""}>${s}</option>`).join("");
    seasonSel.dataset.filled = d.seasons.join(",");
  }

  // KPI cards
  const k = d.kpis;
  document.getElementById("anKpis").innerHTML = k ? [
    ["Points scored", k.totalActual, `${k.weeks} weeks · ${k.avgPerWeek}/wk`],
    ["Best possible", k.totalOptimal, "if lineup was optimal"],
    ["Lineup efficiency", k.efficiency != null ? k.efficiency + "%" : "–", "actual ÷ best possible"],
    ["Left on bench", k.leftOnBench, "points"],
    ["Best week", k.bestWeek ? k.bestWeek.points : "–", k.bestWeek ? "Week " + k.bestWeek.week : ""],
    ["Worst week", k.worstWeek ? k.worstWeek.points : "–", k.worstWeek ? "Week " + k.worstWeek.week : ""],
  ].map(([l, v, s]) => `<div class="kpi"><div class="k-label">${l}</div><div class="k-value">${v}</div><div class="k-sub">${s}</div></div>`).join("") : "";
  document.getElementById("anWeeklyNote").textContent = d.notes.weekly || "";

  // Weekly charts
  const w = d.weekly;
  showCard("cardWeekly", w.length > 0);
  showCard("cardBench", w.length > 0);
  if (w.length) {
    mkChart("chWeekly", {
      type: "line",
      data: { labels: w.map(x => "Wk " + x.week), datasets: [
        { label: "Actual points", data: w.map(x => x.actual), borderColor: GOLD, backgroundColor: GOLD, tension: 0.25 },
        { label: "Best possible lineup", data: w.map(x => x.optimal), borderColor: BLUE, backgroundColor: BLUE, borderDash: [6, 4], tension: 0.25 },
      ] },
      options: { plugins: { title: chartTitle("Points scored vs. best possible lineup") } },
    });
    mkChart("chBench", {
      type: "bar",
      data: { labels: w.map(x => "Wk " + x.week), datasets: [{ label: "Points left on bench", data: w.map(x => x.leftOnBench), backgroundColor: RUST }] },
      options: { plugins: { legend: { display: false }, title: chartTitle("Points left on the bench, by week") } },
    });
  }

  // Position + top scorers
  showCard("cardPos", d.positionBreakdown.length > 0);
  if (d.positionBreakdown.length) {
    mkChart("chPos", {
      type: "doughnut",
      data: { labels: d.positionBreakdown.map(p => p.position), datasets: [{ data: d.positionBreakdown.map(p => p.points), backgroundColor: d.positionBreakdown.map(p => POS_COLORS[p.position] || SILVER), borderColor: "#0a1226" }] },
      options: { plugins: { title: chartTitle("Started points by position") } },
    });
  }
  showCard("cardTop", d.topScorers.length > 0);
  if (d.topScorers.length) {
    mkChart("chTop", {
      type: "bar",
      data: { labels: d.topScorers.map(p => p.name), datasets: [{ label: "Started points", data: d.topScorers.map(p => p.points), backgroundColor: GOLD }] },
      options: { indexAxis: "y", plugins: { legend: { display: false }, title: chartTitle("Top scorers in your starting lineup") } },
    });
  }

  // Trades
  const playerTrades = d.trades.filter(t => !t.picksOnly);
  showCard("cardTrade", playerTrades.length > 0);
  if (playerTrades.length) {
    mkChart("chTrade", {
      type: "bar",
      data: { labels: playerTrades.map(t => `Wk ${t.week}: ${t.playersReceived[0] || t.playersSent[0] || "trade"}`),
        datasets: [{ label: "Net points", data: playerTrades.map(t => t.net), backgroundColor: playerTrades.map(t => t.net >= 0 ? TURF : RUST) }] },
      options: { plugins: { legend: { display: false }, title: chartTitle("Trade value: points received minus points given up") } },
    });
  }
  const fmtPick = (p) => {
    const base = escapeHtml(p.label) + " <em>(pick)</em>";
    if (!p.resolved) return `${base} &mdash; <span style="color:var(--chalk-faint);">${escapeHtml(p.reason)}</span>`;
    return `${base} &rarr; <strong>${escapeHtml(p.playerName)}</strong>` +
      (p.draftedBy ? ` (drafted by ${escapeHtml(p.draftedBy)})` : "") +
      (p.seasonPoints != null ? `, ${p.seasonPoints} pts that season` : "");
  };
  const list = (players, picks) => [...players.map(escapeHtml), ...picks.map(fmtPick)].join(", ") || "&ndash;";
  document.getElementById("anTrades").innerHTML = anTable(
    ["Season", "Wk", "You received", "You sent", "Pts received", "Pts given up", "Net"],
    d.trades.map(t => [t.season, t.week, list(t.playersReceived, t.picksReceived), list(t.playersSent, t.picksSent),
      t.picksOnly ? "picks only" : fmt(t.pointsReceived), t.picksOnly ? "picks only" : fmt(t.pointsGivenUp), t.picksOnly ? "&ndash;" : signed(t.net)]),
    d.notes.trades,
    4
  );

  // Keepers
  const kp = d.keepers.filter(x => x.pointsPerCost != null);
  showCard("cardKeeper", kp.length > 0);
  if (kp.length) {
    mkChart("chKeeper", {
      type: "bar",
      data: { labels: kp.map(x => `${x.playerName} '${String(x.season).slice(2)}`), datasets: [{ label: "Points per cost point", data: kp.map(x => x.pointsPerCost), backgroundColor: BLUE }] },
      options: { plugins: { legend: { display: false }, title: chartTitle(`Keeper return: points per cost point (${d.season || "all seasons"})`) } },
    });
  }
  document.getElementById("anKeepers").innerHTML = anTable(
    ["Season", "Player", "Cost", "Season pts", "Pts per cost pt"],
    d.keepers.map(x => [x.season + (x.current ? " (current)" : ""), escapeHtml(x.playerName), fmt(x.cost), fmt(x.seasonPoints), fmt(x.pointsPerCost)]),
    d.notes.keepers
  );

  // Draft
  const dr = d.draft.filter(x => x.seasonPoints != null);
  showCard("cardDraft", dr.length > 0);
  if (dr.length) {
    mkChart("chDraft", {
      type: "scatter",
      data: { datasets: [{ label: "Draft picks", data: dr.map(x => ({ x: x.round, y: x.seasonPoints, name: x.playerName, season: x.season })), backgroundColor: GOLD, pointRadius: 6 }] },
      options: {
        plugins: { legend: { display: false }, title: chartTitle(`Draft value: round vs. points (${d.season || "all seasons"})`),
          tooltip: { callbacks: { label: (c) => `${c.raw.name} ('${String(c.raw.season).slice(2)}, Rd ${c.raw.x}): ${c.raw.y} pts` } } },
        scales: { x: { title: { display: true, text: "Round" }, ticks: { stepSize: 1 } }, y: { title: { display: true, text: "Season points" } } },
      },
    });
  }
  document.getElementById("anDraft").innerHTML = anTable(
    ["Season", "Player", "Rd", "Pick", "Pos", "Season pts", "Round avg", "vs avg"],
    d.draft.map(x => [x.season, escapeHtml(x.playerName), x.round, x.pickNo, x.position || "&ndash;", fmt(x.seasonPoints), fmt(x.roundAverage), signed(x.vsRound)]),
    d.notes.draft
  );
}

// ---------- League analytics (home page) ----------
async function loadLeagueAnalytics(season) {
  const note = document.getElementById("leagueAnNote");
  const body = document.getElementById("leagueAnBody");
  if (!note || !window.Chart) return;
  let d;
  try {
    d = await api("/analytics/league" + (season ? `?season=${season}` : ""));
  } catch (err) {
    note.textContent = "Couldn't load league analytics: " + err.message;
    return;
  }
  if (!d.season || !d.teams.length) {
    note.textContent = 'No weekly scores yet. Click "Sync Weekly Scores" in the top bar.';
    body.style.display = "none";
    return;
  }
  note.textContent = "";
  body.style.display = "";
  document.getElementById("leagueAnSub").textContent = `Season ${d.season} · points scored vs. best possible lineup`;
  const sel = document.getElementById("leagueAnSeason");
  if (sel.dataset.filled !== d.seasons.join(",")) {
    sel.innerHTML = d.seasons.map(s => `<option value="${s}" ${s === d.season ? "selected" : ""}>${s}</option>`).join("");
    sel.dataset.filled = d.seasons.join(",");
  }

  mkChart("chLeagueTotals", {
    type: "bar",
    data: { labels: d.teams.map(t => t.ownerName), datasets: [
      { label: "Actual", data: d.teams.map(t => t.actual), backgroundColor: GOLD },
      { label: "Best possible", data: d.teams.map(t => t.optimal), backgroundColor: BLUE },
    ] },
    options: { plugins: { title: chartTitle("Total points: actual vs. best possible lineup") } },
  });
  const byEff = [...d.teams].filter(t => t.efficiency != null).sort((a, b) => b.efficiency - a.efficiency);
  mkChart("chLeagueEff", {
    type: "bar",
    data: { labels: byEff.map(t => t.ownerName), datasets: [{ label: "Lineup efficiency %", data: byEff.map(t => t.efficiency), backgroundColor: ROYAL }] },
    options: { indexAxis: "y", plugins: { legend: { display: false }, title: chartTitle("Lineup efficiency (who sets the best lineups)") } },
  });
  mkChart("chLeagueWeekly", {
    type: "line",
    data: { labels: d.weekly.map(w => "Wk " + w.week), datasets: [
      { label: "League avg actual", data: d.weekly.map(w => w.avgActual), borderColor: GOLD, backgroundColor: GOLD, tension: 0.25 },
      { label: "League avg best possible", data: d.weekly.map(w => w.avgOptimal), borderColor: BLUE, backgroundColor: BLUE, borderDash: [6, 4], tension: 0.25 },
    ] },
    options: { plugins: { title: chartTitle("League average scoring by week") } },
  });
}

// ---------- Newsletter ----------
function renderNewsBody(text) {
  return escapeHtml(text).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
}

async function loadNewsletters() {
  const el = document.getElementById("newsletterList");
  if (!el) return;
  try {
    const items = await api("/copilot/newsletters");
    el.innerHTML = items.length
      ? items.map((n, i) => `
        <div class="news-item">
          <div class="news-title">${escapeHtml(n.title)}</div>
          <div class="news-body collapsed" id="newsBody${i}">${renderNewsBody(n.content)}</div>
          <button class="news-expand-btn" onclick="toggleNewsItem('newsBody${i}', this)">Show full storyline &#9662;</button>
        </div>`).join("")
      : `<div class="empty-note">No storyline yet — one is written automatically once this week's games finish, and shortly after each "Sync Weekly Scores" click. Check back after Sunday's games.</div>`;
    // Only show the expand button on items that are actually clipped.
    items.forEach((_, i) => {
      const body = document.getElementById(`newsBody${i}`);
      const btn = body && body.nextElementSibling;
      if (body && btn && body.scrollHeight <= body.clientHeight + 4) btn.style.display = "none";
    });
  } catch (err) {
    el.innerHTML = `<div class="empty-note">Couldn't load newsletters: ${escapeHtml(err.message)}</div>`;
  }
}

function toggleNewsItem(bodyId, btn) {
  const body = document.getElementById(bodyId);
  const collapsed = body.classList.toggle("collapsed");
  btn.innerHTML = collapsed ? "Show full storyline &#9662;" : "Show less &#9652;";
}

async function loadRecoveryLog() {
  try {
    const rows = await api("/teams/recovery-log");
    const panel = document.getElementById("recoveryPanel");
    if (!rows.length) { panel.style.display = "none"; return; }
    panel.style.display = "block";
    document.getElementById("recoveryList").innerHTML = rows.map(r => `
      <div class="news-item" style="padding:10px 14px; font-size:13px;">
        <strong>${escapeHtml(r.owner_name)}</strong> &mdash; ${escapeHtml(r.message)}
        <div style="color:var(--chalk-faint); font-size:11px; margin-top:4px;">${new Date(r.created_at).toLocaleString()}</div>
      </div>
    `).join("");
  } catch (err) { /* non-critical panel; fail quietly */ }
}

async function checkEnv() {
  try {
    const h = await api("/health");
    const banner = document.getElementById("envBanner");
    if (!h.env.sleeperLeagueId) {
      banner.style.display = "block";
      banner.innerHTML = "&#9888; <code>SLEEPER_LEAGUE_ID</code> is not set in your .env file &mdash; syncing won't work until you add it and restart.";
    }
  } catch (err) { /* health check itself failing isn't worth blocking the page for */ }
}

// ---------- Playoff Predictor ----------
async function loadPlayoffOdds() {
  const el = document.getElementById("playoffOddsBody");
  el.innerHTML = "<div class='empty-note'>Simulating 3,000 seasons&hellip;</div>";
  let d;
  try {
    d = await api("/predictor/playoffs");
  } catch (err) {
    el.innerHTML = `<div class="empty-note">Couldn't load playoff odds: ${escapeHtml(err.message)}</div>`;
    return;
  }
  if (!d.teams || !d.teams.length) {
    el.innerHTML = "<div class='empty-note'>No teams found yet &mdash; try Sync Now first.</div>";
    return;
  }
  const maxOdds = Math.max(...d.teams.map(t => t.playoffOdds), 1);
  el.innerHTML = `<div class="an-note">Season ${escapeHtml(String(d.season))} &middot; through week ${d.currentWeek} &middot; ${d.remainingWeeksSimulated} week(s) simulated &middot; ${d.iterations} iterations</div>` +
    `<table class="odds-table"><thead><tr><th>Team</th><th>Record</th><th>Playoff Odds</th><th>Avg Finish</th><th>Score Mean / Std</th></tr></thead><tbody>` +
    d.teams.map(t => `
      <tr>
        <td>${escapeHtml(t.ownerName)}</td>
        <td>${escapeHtml(t.record)}</td>
        <td>
          <div style="display:flex; align-items:center; gap:10px;">
            <div class="odds-bar-wrap"><div class="odds-bar" style="width:${(t.playoffOdds / maxOdds) * 100}%;"></div></div>
            <span>${t.playoffOdds}%</span>
          </div>
        </td>
        <td>${t.avgFinishRank}</td>
        <td>${t.scoreMean} / ${t.scoreStd}</td>
      </tr>`).join("") +
    `</tbody></table>`;
}

async function loadDraftOrder() {
  const el = document.getElementById("draftOrderBody");
  el.innerHTML = "<div class='empty-note'>Running lottery simulation (5,000 draws)&hellip;</div>";
  let d;
  try {
    d = await api("/predictor/draft-order");
  } catch (err) {
    el.innerHTML = `<div class="empty-note">Couldn't load draft order: ${escapeHtml(err.message)}</div>`;
    return;
  }

  const playoffHtml = `<h4 class="an-h" style="margin-top:0;">Picks 7&ndash;12 (by estimated playoff finish)</h4>` +
    `<table class="odds-table"><thead><tr><th>Pick</th><th>Team</th></tr></thead><tbody>` +
    d.playoffPickOrder.map(p => `<tr><td>${p.pick}</td><td>${escapeHtml(p.ownerName)}</td></tr>`).join("") +
    `</tbody></table>`;

  const lotteryHeader = `<th>Team</th><th>Base Odds</th>` + [1,2,3,4,5,6].map(p => `<th>Pick ${p}</th>`).join("");
  const lotteryRows = d.lotteryProbabilities.map(t => {
    const cells = t.pickProbabilities.map(pp => `<td>${pp.probability}%</td>`).join("");
    return `<tr><td>${escapeHtml(t.ownerName)}</td><td>${escapeHtml(t.baseOdds)}</td>${cells}</tr>`;
  }).join("");
  const sampleHtml = `<div class="an-note">Example single draw: ${d.sampleLotteryResult.map(s => `Pick ${s.pick} &rarr; ${escapeHtml(s.ownerName)}`).join(" &middot; ")}</div>`;

  el.innerHTML = playoffHtml +
    `<h4 class="an-h">Picks 1&ndash;6 Lottery (probability of landing each pick)</h4>` +
    `<div style="overflow-x:auto;"><table class="odds-table"><thead><tr>${lotteryHeader}</tr></thead><tbody>${lotteryRows}</tbody></table></div>` +
    sampleHtml;
}

// ---------- Mock Draft ----------
let mockDraftState = null;

async function startMockDraft() {
  const raw = document.getElementById("mockOrderInput").value.trim();
  if (!raw) { alert("Enter the team IDs in draft order, comma-separated."); return; }
  const order = raw.split(",").map(s => Number(s.trim())).filter(n => !isNaN(n));
  if (!order.length) { alert("Couldn't parse any team IDs."); return; }
  try {
    await api("/predictor/mock-draft/start", { method: "POST", body: JSON.stringify({ order }) });
    loadMockDraft();
  } catch (err) { alert(err.message); }
}

async function resetMockDraft() {
  if (!confirm("Reset the mock draft? This clears the order and all picks made so far.")) return;
  try {
    await api("/predictor/mock-draft/reset", { method: "POST" });
    loadMockDraft();
  } catch (err) { alert(err.message); }
}

async function loadMockDraft() {
  const pos = document.getElementById("poolPosition")?.value || "";
  const params = pos ? `?position=${encodeURIComponent(pos)}` : "";
  let d;
  try {
    d = await api(`/predictor/mock-draft${params}`);
  } catch (err) {
    document.getElementById("mockOnClock").innerHTML = `<div class="empty-note">Couldn't load mock draft: ${escapeHtml(err.message)}</div>`;
    return;
  }
  mockDraftState = d;

  const onClockEl = document.getElementById("mockOnClock");
  if (!d.order) {
    onClockEl.innerHTML = `<div class="empty-note">No mock draft started yet &mdash; enter a team order above and click Start.</div>`;
  } else if (d.onTheClockPick == null || d.onTheClockPick > d.totalPicks) {
    onClockEl.innerHTML = `<div class="on-clock"><span class="who">Draft complete</span><span>${d.picks.length} picks made</span></div>`;
  } else {
    const teamName = await teamNameFor(d.onTheClockTeamId);
    onClockEl.innerHTML = `<div class="on-clock"><span>Pick ${d.onTheClockPick} of ${d.totalPicks}</span><span class="who">On the clock: ${escapeHtml(teamName)}</span></div>`;
  }

  document.getElementById("mockPicksList").innerHTML = d.picks.length
    ? d.picks.map(p => `<div class="pk-row"><span class="pk-no">#${p.pick_no}</span><span>${escapeHtml(p.player_name)} <span class="pos-pill">${p.position || ""}</span></span><span>${escapeHtml(p.owner_name || "—")}</span></div>`).join("")
    : `<div class="empty-note">No picks made yet.</div>`;

  renderMockPool();
}

let teamNameCache = null;
async function teamNameFor(teamId) {
  if (!teamNameCache) {
    try { teamNameCache = await api("/teams"); } catch (err) { teamNameCache = []; }
  }
  const t = teamNameCache.find(t => t.id === teamId);
  return t ? t.ownerName : `Team ${teamId}`;
}

function renderMockPool() {
  if (!mockDraftState) return;
  const q = (document.getElementById("poolSearch")?.value || "").toLowerCase();
  const list = document.getElementById("mockPoolList");
  const pool = (mockDraftState.pool || []).filter(p => !q || p.name.toLowerCase().includes(q));
  const canDraft = mockDraftState.order && mockDraftState.onTheClockPick && mockDraftState.onTheClockPick <= mockDraftState.totalPicks;
  list.innerHTML = pool.slice(0, 150).map(p => `
    <div class="pool-row">
      <span class="pr-name">${escapeHtml(p.name)} <span class="pos-pill">${p.position}</span> ${p.nflTeam ? `<span style="color:var(--chalk-faint); font-size:11px;">${escapeHtml(p.nflTeam)}</span>` : ""}</span>
      <button class="btn btn-small" ${canDraft ? "" : "disabled"} onclick="draftMockPlayer('${p.id}')">Draft</button>
    </div>`).join("") || `<div class="empty-note">No players match.</div>`;
}

async function draftMockPlayer(sleeperPlayerId) {
  try {
    await api("/predictor/mock-draft/pick", { method: "POST", body: JSON.stringify({ sleeperPlayerId }) });
    loadMockDraft();
  } catch (err) { alert(err.message); }
}

// ---------- Trade Analyzer ----------
let tradeTeamsCache = null;
let tradeSelections = { A: new Set(), B: new Set() };
let tradePicks = { A: [], B: [] };

async function loadTradeTeams() {
  tradeSelections = { A: new Set(), B: new Set() };
  tradePicks = { A: [], B: [] };
  document.getElementById("tradeResultArea").innerHTML = "";
  renderPickList("A");
  renderPickList("B");
  loadPickValueNote();
  try {
    tradeTeamsCache = await api("/teams");
  } catch (err) {
    document.getElementById("tradeResultArea").innerHTML = `<div class="empty-note">Couldn't load teams: ${escapeHtml(err.message)}</div>`;
    return;
  }
  const opts = (selected) => `<option value="">Select a team&hellip;</option>` + tradeTeamsCache.map(t =>
    `<option value="${t.id}" ${String(t.id) === String(selected) ? "selected" : ""}>${escapeHtml(t.ownerName)}</option>`).join("");
  document.getElementById("tradeTeamA").innerHTML = opts();
  document.getElementById("tradeTeamB").innerHTML = opts();
  document.getElementById("tradeRosterA").innerHTML = "";
  document.getElementById("tradeRosterB").innerHTML = "";
}

async function loadPickValueNote() {
  const note = document.getElementById("pickValueNote");
  if (!note) return;
  try {
    const d = await api("/trade-analyzer/pick-value");
    note.textContent = `${d.pointsPerWeek} pts/week (this year's round-1 picks' average so far, from ${d.playersConsidered} player${d.playersConsidered === 1 ? "" : "s"}).`;
  } catch (err) {
    note.textContent = "unavailable (" + err.message + ")";
  }
}

function addTradePick(side) {
  const season = document.getElementById(`pickSeason${side}`).value.trim() || "Future";
  const round = document.getElementById(`pickRound${side}`).value;
  const roundLabel = round === "8" ? "8th+" : `${round}${{1:"st",2:"nd",3:"rd"}[round] || "th"}`;
  tradePicks[side].push({ season, round: Number(round), label: `${season} ${roundLabel} Rd` });
  renderPickList(side);
}

function removeTradePick(side, idx) {
  tradePicks[side].splice(idx, 1);
  renderPickList(side);
}

function renderPickList(side) {
  const el = document.getElementById(`pickList${side}`);
  if (!el) return;
  el.innerHTML = tradePicks[side].map((p, i) =>
    `<span class="pick-chip">${escapeHtml(p.label)} <button onclick="removeTradePick('${side}', ${i})" aria-label="Remove pick">&times;</button></span>`
  ).join("");
}

async function loadTradeRoster(side) {
  const teamId = document.getElementById(`tradeTeam${side}`).value;
  const rosterEl = document.getElementById(`tradeRoster${side}`);
  tradeSelections[side] = new Set();
  if (!teamId) { rosterEl.innerHTML = ""; return; }
  const team = tradeTeamsCache.find(t => String(t.id) === String(teamId));
  if (!team) { rosterEl.innerHTML = ""; return; }
  rosterEl.innerHTML = team.players.filter(p => p.sleeper_player_id).map(p => `
    <label>
      <input type="checkbox" onchange="toggleTradePlayer('${side}','${p.sleeper_player_id}', this.checked)">
      ${escapeHtml(p.player_name)} <span class="pos-pill">${p.position || ""}</span>
      ${p.is_keeper ? '<span style="color:var(--gold); font-size:11px;">Keeper</span>' : ""}
    </label>`).join("") || `<div class="empty-note">No active Sleeper roster found for this team.</div>`;
}

function toggleTradePlayer(side, playerId, checked) {
  if (checked) tradeSelections[side].add(playerId);
  else tradeSelections[side].delete(playerId);
}

async function previewTrade() {
  const teamA = document.getElementById("tradeTeamA").value;
  const teamB = document.getElementById("tradeTeamB").value;
  const resultEl = document.getElementById("tradeResultArea");
  if (!teamA || !teamB) { alert("Select a team on both sides first."); return; }
  if (!tradeSelections.A.size && !tradeSelections.B.size && !tradePicks.A.length && !tradePicks.B.length) {
    alert("Select at least one player or add at least one pick on one side."); return;
  }

  resultEl.innerHTML = "<div class='empty-note'>Projecting&hellip;</div>";
  let d;
  try {
    d = await api("/trade-analyzer/preview", {
      method: "POST",
      body: JSON.stringify({
        sideA: { teamId: Number(teamA), playerIds: [...tradeSelections.A], picks: tradePicks.A },
        sideB: { teamId: Number(teamB), playerIds: [...tradeSelections.B], picks: tradePicks.B },
      }),
    });
  } catch (err) {
    resultEl.innerHTML = `<div class="empty-note">Couldn't preview trade: ${escapeHtml(err.message)}</div>`;
    return;
  }

  const sideCard = (s) => {
    const rows = [
      ...s.players.map(p => [escapeHtml(p.name), p.position || "–", p.pointsPerGame, p.projectedRemainingPoints]),
      ...s.picks.map(p => [escapeHtml(p.label), "PICK", p.pointsPerGame, p.projectedRemainingPoints]),
    ];
    return `
    <div class="trade-result-card">
      <div class="display" style="font-size:14px;">${escapeHtml(s.teamName || "Team")}</div>
      <div class="an-note">${d.remainingWeeks} week(s) remaining before playoffs (week ${d.playoffStart})</div>
      <div style="margin:10px 0;">
        <div>Sends away: <strong>${s.pointsGiven}</strong> projected pts</div>
        <div>Receives: <strong>${s.pointsReceived}</strong> projected pts</div>
        <div class="net ${s.net >= 0 ? "pos" : "neg"}">${s.net > 0 ? "+" : ""}${s.net} net</div>
      </div>
      ${rows.length ? anTable(["Player / Pick","Pos","Pts/gm","Proj remaining"], rows) : "<div class='empty-note'>Nothing selected on this side.</div>"}
    </div>`;
  };

  resultEl.innerHTML = `<div class="trade-result">${sideCard(d.sideA)}${sideCard(d.sideB)}</div>` +
    (d.warnings.length ? `<div class="warn-box"><strong>&#9888; Heads up:</strong><ul>${d.warnings.map(w => `<li>${escapeHtml(w)}</li>`).join("")}</ul></div>` : "");
}

checkEnv();
buildGrid();
loadNewsletters();
loadLeagueAnalytics();
loadRecoveryLog();
