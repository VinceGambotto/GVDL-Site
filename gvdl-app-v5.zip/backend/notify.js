const { pool } = require("./db");

/**
 * Records and surfaces a PIN-recovery event. There's no email/SMS service
 * configured here (that needs real credentials this app doesn't have), so
 * this always does two free, zero-setup things:
 *   1. A loud console log line, visible in `docker compose up` / container logs.
 *   2. A row in recovery_log, shown in a "Recovery Activity" panel on the
 *      site's home page — so you'll see it just by opening the app.
 * If RECOVERY_WEBHOOK_URL is set (a Discord or Slack incoming webhook URL,
 * both free), it also posts a message there for a real push notification.
 */
async function notifyRecovery({ teamId, ownerName }) {
  const message = `PIN recovery used for "${ownerName}" — their PIN was cleared with the master code. They can set a new one now.`;
  console.log(`\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n!! [RECOVERY] ${message}\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n`);

  await pool.query(
    "INSERT INTO recovery_log (team_id, owner_name, message) VALUES ($1,$2,$3)",
    [teamId, ownerName, message]
  );

  const webhook = process.env.RECOVERY_WEBHOOK_URL;
  if (webhook) {
    try {
      await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: `🔑 GVDL: ${message}`, text: `🔑 GVDL: ${message}` }),
      });
    } catch (err) {
      console.warn("[notify] webhook post failed:", err.message);
    }
  }
}

module.exports = { notifyRecovery };
