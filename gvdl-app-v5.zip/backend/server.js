require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");
const cron = require("node-cron");

const { run: migrate } = require("./migrate");
const { runSync } = require("./sync");
const { generateAndStoreWeeklyNewsletter, ensureLatestStorylineGenerated } = require("./newsletter");

const teamsRouter = require("./routes/teams");
const syncRouter = require("./routes/sync");
const copilotRouter = require("./routes/copilot");
const historyRouter = require("./routes/history");
const analyticsRouter = require("./routes/analytics");
const leagueAnalyticsRouter = require("./routes/leagueAnalytics");
const predictorRouter = require("./routes/predictor");
const tradeAnalyzerRouter = require("./routes/tradeAnalyzer");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/teams", teamsRouter);
app.use("/api/sync", syncRouter);
app.use("/api/copilot", copilotRouter);
app.use("/api/history", historyRouter);
app.use("/api/teams", analyticsRouter);
app.use("/api/analytics", leagueAnalyticsRouter);
app.use("/api/predictor", predictorRouter);
app.use("/api/trade-analyzer", tradeAnalyzerRouter);

app.get("/api/health", (req, res) => res.json({
  ok: true,
  env: {
    sleeperLeagueId: !!process.env.SLEEPER_LEAGUE_ID,
    geminiKey: !!process.env.GEMINI_API_KEY,
  },
}));

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = process.env.PORT || 4000;

async function start() {
  console.log("\n================ GVDL startup ================");
  if (!process.env.SLEEPER_LEAGUE_ID) {
    console.log("!! SLEEPER_LEAGUE_ID is NOT set. Nothing will sync from Sleeper.");
    console.log("!! Fix: add SLEEPER_LEAGUE_ID=<your league id> to .env, then restart.");
  } else {
    console.log(`OK  SLEEPER_LEAGUE_ID = ${process.env.SLEEPER_LEAGUE_ID}`);
  }
  if (!process.env.GEMINI_API_KEY) {
    console.log("--  GEMINI_API_KEY is not set. The weekly report / AI features are disabled (everything else still works).");
  } else {
    console.log("OK  GEMINI_API_KEY is set.");
  }
  console.log("================================================\n");

  await migrate();

  // Kick off one sync shortly after boot, then on a schedule.
  setTimeout(() => runSync(), 3000);
  // Also check for a missing storyline shortly after boot, so a fresh
  // install doesn't sit with an empty panel until Wednesday.
  setTimeout(() => ensureLatestStorylineGenerated(), 15000);

  const minutes = Math.max(5, Number(process.env.SYNC_INTERVAL_MINUTES) || 30);
  cron.schedule(`*/${minutes} * * * *`, () => {
    console.log(`[cron] running scheduled sync (every ${minutes}m)`);
    runSync();
  });

  // Newsletter: every Wednesday at 9:00 AM server time, covering the week that just finished.
  cron.schedule("0 9 * * 3", () => {
    console.log("[cron] generating weekly newsletter");
    generateAndStoreWeeklyNewsletter();
  });

  app.listen(PORT, () => {
    console.log(`GVDL API listening on :${PORT}`);
  });
}

start().catch((err) => {
  console.error("Fatal startup error:", err);
  process.exit(1);
});
