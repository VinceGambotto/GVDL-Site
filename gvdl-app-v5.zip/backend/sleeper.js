// Thin client for Sleeper's public read-only API.
// Docs: https://docs.sleeper.com/
//
// No API key needed. The one endpoint that must be cached rather than
// hit repeatedly is /players/nfl — it's a multi-MB dump of every NFL
// player and Sleeper's own docs ask you to call it at most once a day.

const fs = require("fs");
const path = require("path");

const BASE = "https://api.sleeper.app/v1";
const PLAYERS_CACHE_PATH = path.join(__dirname, "cache", "players.json");
const PLAYERS_CACHE_MAX_AGE_MS = 20 * 60 * 60 * 1000; // ~20h, under Sleeper's "once a day" ask

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Sleeper request failed (${res.status}): ${url}`);
  }
  return res.json();
}

function getLeague(leagueId) {
  return getJSON(`${BASE}/league/${leagueId}`);
}

function getRosters(leagueId) {
  return getJSON(`${BASE}/league/${leagueId}/rosters`);
}

function getUsers(leagueId) {
  return getJSON(`${BASE}/league/${leagueId}/users`);
}

// All transaction types (trade, waiver, free_agent) for a given week.
function getTransactions(leagueId, week) {
  return getJSON(`${BASE}/league/${leagueId}/transactions/${week}`);
}

// type: "trade" transactions show up per "round" (week). We sweep 1..18
// which covers a full regular + post season; harmless to over-fetch.
async function getAllTradeTransactions(leagueId) {
  const trades = [];
  for (let week = 1; week <= 18; week++) {
    try {
      const txns = await getJSON(`${BASE}/league/${leagueId}/transactions/${week}`);
      for (const t of txns) {
        if (t.type === "trade" && t.status === "complete") trades.push(t);
      }
    } catch (err) {
      // A missing week (season not that far along yet) is normal, not fatal.
      console.warn(`[sleeper] transactions week ${week} skipped: ${err.message}`);
    }
  }
  return trades;
}

// Returns each roster's starters, full player list, and per-player points
// for a given week. This is the one call that gives us everything needed
// for actual-vs-optimal-lineup analytics — no separate stats endpoint needed.
function getMatchups(leagueId, week) {
  return getJSON(`${BASE}/league/${leagueId}/matchups/${week}`);
}

function getState() {
  return getJSON(`${BASE}/state/nfl`);
}

function getLeagueDrafts(leagueId) {
  return getJSON(`${BASE}/league/${leagueId}/drafts`);
}

function getDraftPicks(draftId) {
  return getJSON(`${BASE}/draft/${draftId}/picks`);
}

// Full draft object: includes slot_to_roster_id (which original roster sits
// in each draft slot) and settings.rounds/type — needed to compute which
// overall pick number a traded future pick turns into.
function getDraft(draftId) {
  return getJSON(`${BASE}/draft/${draftId}`);
}

// Sleeper leagues are one object per season, chained backward via
// previous_league_id. This walks that chain so we can see draft rounds
// from past seasons, not just the current one. Capped at maxSeasons so a
// very old league doesn't turn into an unbounded crawl.
async function getLeagueSeasonChain(leagueId, maxSeasons = 6) {
  const chain = [];
  let currentId = leagueId;
  for (let i = 0; i < maxSeasons && currentId; i++) {
    const league = await getLeague(currentId);
    chain.push(league);
    currentId = league.previous_league_id || null;
  }
  return chain;
}

let playersMemo = null;
let playersMemoAt = 0;

async function getAllPlayers({ forceRefresh = false } = {}) {
  if (!forceRefresh && playersMemo && Date.now() - playersMemoAt < PLAYERS_CACHE_MAX_AGE_MS) return playersMemo;
  playersMemo = null;
  try {
    if (!forceRefresh && fs.existsSync(PLAYERS_CACHE_PATH)) {
      const stat = fs.statSync(PLAYERS_CACHE_PATH);
      if (Date.now() - stat.mtimeMs < PLAYERS_CACHE_MAX_AGE_MS) {
        playersMemo = JSON.parse(fs.readFileSync(PLAYERS_CACHE_PATH, "utf8"));
        playersMemoAt = Date.now();
        return playersMemo;
      }
    }
  } catch (err) {
    console.warn("[sleeper] player cache read failed, refetching", err.message);
  }

  const players = await getJSON(`${BASE}/players/nfl`);
  fs.mkdirSync(path.dirname(PLAYERS_CACHE_PATH), { recursive: true });
  fs.writeFileSync(PLAYERS_CACHE_PATH, JSON.stringify(players));
  playersMemo = players;
  playersMemoAt = Date.now();
  return players;
}

module.exports = {
  getLeague,
  getRosters,
  getUsers,
  getAllTradeTransactions,
  getState,
  getAllPlayers,
  getLeagueDrafts,
  getDraftPicks,
  getDraft,
  getLeagueSeasonChain,
  getMatchups,
  getTransactions,
};
