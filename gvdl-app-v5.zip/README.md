# GVDL

A self-hosted keeper-league tracker for your 12-team league:

- **Live Sleeper sync** — rosters and trades pull straight from your real Sleeper league on a schedule (default every 30 min), plus a manual "Sync Now" button.
- **Keeper tracking** — each owner marks which of their current players they're keeping and at what point cost; last year's (2025) keeper history is seeded in as read-only reference.
- **Points & trades remaining** — computed from your keeper rules and real Sleeper trade transactions, not manual counters.
- **PIN-protected teams** — each owner sets their own PIN. It's hashed with bcrypt server-side and never stored or sent in plain text, so this is real protection, not the "soft lock" version from the static HTML page.
- **AI weekly report** — a free Google Gemini key writes a weekly report covering headlines, breaking news (trades), and roster moves by team. No cost, no Anthropic key needed.

Runs entirely on your own infrastructure via Docker — nothing here depends on Claude.ai once it's running.

## 1. Get what you need first

- **Your Sleeper league ID.** Open your league on sleeper.com or in the app; the numeric ID is in the URL: `sleeper.com/leagues/XXXXXXXXXXXXXXXXXX/team`.
- **A free Google Gemini API key**, from https://aistudio.google.com/app/apikey — only needed for the AI weekly report / storyline features. Everything else works without it, and this is a normal free-tier key, not a paid one.
- **Docker and Docker Compose** installed. Docker Desktop covers both on Mac/Windows; on Linux install `docker` and the `docker compose` plugin.
- **A place to run it.** Your own computer works for testing, but it needs to stay on for the league to reach it and for scheduled syncs to run. For a league site people actually use day-to-day, a small always-on box (a Raspberry Pi, an old computer, or a cheap VPS like a $5-6/mo DigitalOcean/Hetzner/Railway instance) is the realistic option.

## 2. Configure

```bash
cp .env.example .env
```

Then edit `.env` and fill in:
- `SLEEPER_LEAGUE_ID`
- `GEMINI_API_KEY` (optional, but the AI weekly report and storylines won't work without it — this is free from Google, not the same thing as an Anthropic key)
- `JWT_SECRET` — any long random string (used to sign the "unlocked" session after a PIN check)
- `POSTGRES_PASSWORD` — fine to leave as the default for local/private use

## 3. Run it

```bash
docker compose up --build
```

First boot will:
1. Start Postgres.
2. Apply the database schema.
3. Seed your 2025 keeper history from the original spreadsheet (already baked into `backend/migrations/seed_history_2025.json`).
4. Run an initial Sleeper sync a few seconds after startup.
5. Start syncing on a schedule after that (`SYNC_INTERVAL_MINUTES` in `.env`, default 30).

Then open **http://localhost:4000** (or your server's address if you deployed it elsewhere).

## 4. Sharing it with your league

Whoever's IP/domain the app is running on, share that URL. If you're running this on a home computer, note that "localhost:4000" only works on that machine — your league needs a real reachable address, which usually means either:
- deploying to a small always-on VPS (recommended for anything beyond testing), or
- using a tunneling tool (like Cloudflare Tunnel or ngrok) to expose your home machine's port 4000 to the internet, or
- port-forwarding on your router (works, but exposes your home network — a VPS or tunnel is safer).

I can help set up any of these if you tell me which one you want to use.

## How the pieces fit together

```
docker-compose.yml       — starts Postgres + the API together
backend/
  server.js              — Express app: wires routes, serves the frontend, runs the sync schedule
  db.js                  — Postgres connection pool
  sleeper.js             — Sleeper API client (public, read-only, no key needed)
  sync.js                — pulls rosters/users/trades from Sleeper into the database
  gemini.js              — calls Google's free Gemini API to write the weekly report and storylines
  auth.js                — bcrypt PIN hashing + JWT session tokens for team locks
  migrate.js             — applies schema.sql and seeds 2025 history on first boot
  migrations/
    schema.sql           — database tables
    seed_history_2025.json — your original spreadsheet, extracted
  routes/
    teams.js              — team list/detail, keeper edits, PIN lock/unlock, trade allowance
    sync.js                — manual sync trigger + sync log
    copilot.js              — AI storyline generation
    history.js               — 2025 keeper reference data
  public/                — the frontend (plain HTML/CSS/JS, no build step)
```

## Notes and honest limitations

- **Sleeper doesn't know your custom keeper rules.** It only knows current rosters and trade history. Keeper flags are something each owner sets manually here — sync will never overwrite a keeper flag you've already set on a player who's still on your Sleeper roster.
- **Keeper cost is now automated from draft history.** Click "Sync Draft History" once (top bar) after setup — it walks your league's current and past drafts on Sleeper (via each season's `previous_league_id` chain) to find each player's most recently drafted round, then "Auto-Fill Costs from Draft" (on a team page) applies the cost table: round 1 = 8pts, 2 = 7, 3 = 6, 4 = 5, 5 = 4, 6 = 3, 7 = 2, round 8-or-later/undrafted = 1pt. It only sets cost, never the keeper checkbox itself — that's still your call. Re-run it any time; it always recomputes from the latest draft data. If a player shows no draft history at all, they're treated as 1-point/undrafted.
- **The 3-consecutive-season keeper cap is tracked, not silently enforced.** A ⚠️ next to a player's name means they've already been kept 3 seasons running by this team and, per your rule, shouldn't be kept again. It's a warning, not a hard block — trades and edge cases in your own rules mean a human should make the final call. This only works going forward from data recorded here: 2025 is seeded (best-effort, matched by player name from your old spreadsheet) when you match a team to its history; every season after that gets recorded properly by "Close Season."
- **Trades remaining** = the allowance you set for a team, minus actual completed trades pulled from Sleeper. If you haven't set an allowance yet, it just shows the raw trade count.
- **Points rollover**: "Close Season" on a team page locks in that season's keepers (for the streak tracker) and computes next season's starting points as 20 (base) + half of whatever was left unused, rounded up — matching your league rule. Do this once per team, once keepers are final for the year.
- **The players endpoint is cached** for about 20 hours per Sleeper's own guidance (it's a multi-MB dump of every NFL player), so a brand-new player showing up mid-week may take up to a day to get a proper name/position instead of a placeholder.
- **PIN protection is real this time** — bcrypt hash stored server-side, verified server-side, never exposed to other viewers. Still no full user-account system (usernames, password reset, etc.) — it's built for a friend league, not a public product.

## Analytics and newsletter

**Buttons in the top bar** (run in this order after setup, then after each week's games):
1. **Sync Now** - rosters and transactions.
2. **Sync Draft History** - each team's draft picks plus each player's most recent round (drives keeper cost and draft analysis). Once after setup, again after each draft.
3. **Sync Weekly Scores** - points and best-possible-lineup points. The first run also reads the previous 2 seasons (about a minute); after that only the current season refreshes.

**League Analytics** (home page): total points vs. best possible lineup for every team, a lineup-efficiency ranking, and league-average scoring by week.

**Team Analytics** (team page, "Load Analytics"): a season picker, KPI cards (points, efficiency, points left on the bench, best/worst week), and charts for points vs. best possible, bench points by week, started points by position, top scorers, trade value, keeper return, and draft value (round vs. points). Below the charts are detail tables for trades (players AND picks, with points received vs. given up), keepers (spreadsheet history plus later seasons) and draft picks (vs. the average for that round).

If a section is empty, it says why and which button to click.

**Storyline**: generated automatically every Wednesday at 9:00 AM server time for the week that just finished — headlines, breaking news (trades), and roster moves grouped by team. It also checks after every "Sync Weekly Scores" and at server startup, so it isn't only tied to the Wednesday schedule. Needs a valid `GEMINI_API_KEY` (free — see above). There's no manual button by design — it's meant to just appear.

Notes:
- "Best possible lineup" is a greedy heuristic (fill exact-position slots, then FLEX/SUPER_FLEX). It is right in normal situations but not a formal optimum, and it counts every rostered player (including IR) as available.
- Keeper history for 2025 comes from your spreadsheet, so the team must be matched with "Rename / Match to 2025 History" first. Names are matched to Sleeper players ignoring punctuation and Jr/Sr suffixes; an unusual spelling may not match and will show no points.
- Trade value counts points scored by the players involved after the trade week, while on the receiving team (points received) and for whoever else held them (points given up).
- Upgrading an existing install: no data wipe needed. New columns and tables are added automatically at startup.

## If a sync ever fails with "SLEEPER_LEAGUE_ID is not set"

This means the app didn't see your `.env` file — it's not a code bug, it's almost always one of:
- `.env` doesn't actually exist next to `docker-compose.yml` (Windows/Notepad sometimes saves it as `.env.txt` — check with `dir -Force`, or `Get-Content .env` to see its real contents).
- You're running `docker compose` from a different folder than the one with `.env` in it.
- You replaced the app folder with a new version and forgot to copy `.env` back in.

As of this version, the terminal log now prints a clear `SLEEPER_LEAGUE_ID is NOT set` warning block every time the server starts, and the website itself shows a red banner at the top of the page when this happens — so it should be obvious immediately rather than only showing up when you click Sync.

## PIN recovery (master code)

Each team sets its own 4-digit PIN, and every team's PIN must be different from every other team's — the app checks this and rejects a duplicate when a PIN is set.

If someone forgets their PIN, they don't have to ask you to dig through a database. On the locked banner for that team, there's a **"Forgot PIN?"** link. Entering the master code there clears that team's PIN (it does *not* log anyone in or reveal the old PIN) — the owner can then set a brand new one right away, the same way they did the first time.

**The master code is `4677` by default.** Change it by setting `MASTER_PIN` in `.env`. Keep it to yourself — anyone who has it can clear any team's PIN.

**You'll always know when it's used**, with no email/SMS setup required:
- A "Recovery Activity" panel appears on the home page automatically whenever a recovery has happened, showing who and when.
- The server's terminal log prints a loud, impossible-to-miss line.
- Optional: set `RECOVERY_WEBHOOK_URL` in `.env` to a free Discord or Slack "incoming webhook" URL to also get a push notification the moment it happens. Real email/text alerts would need a mail or SMS provider's credentials, which isn't set up here — the webhook is the free option; ask if you want help wiring up an actual email/SMS provider instead.

## Year filtering and traded-pick tracing

- **Draft analysis and keeper history** now respect the season dropdown on a team's Analytics panel — pick a year to see only that year's picks/keepers.
- **Trade history** deliberately shows every season together (it's meant to be full history), but each trade is now labeled with its season, and a bug where a past trade's point values were calculated using the current season instead of the season the trade actually happened in is fixed.
- **Past trades were missing entirely for some of you** — the sync only ever asked Sleeper about the current season's league. It now walks every past season the same way draft history does, so re-run **Sync Now** once after this update to backfill prior years.
- **Traded picks are now traced forward**: if you ever traded a future pick, the trade history shows who actually ended up drafting with it and what they got, once that draft has happened (e.g. "2026 Round 1 (Alec's) → Bijan Robinson (drafted by Ben), 187 pts that season"). This needs **Sync Draft History** to have run for that season, since a draft's pick order (and therefore which pick number a traded slot becomes) isn't knowable until Sleeper has it.
